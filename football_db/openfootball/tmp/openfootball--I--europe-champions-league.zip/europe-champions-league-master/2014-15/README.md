

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Juventus                       1   1  0  0   2:0     0  0  0   0:0      2:0    +2    3
 2. Olympiakos Piräus              1   1  0  0   3:2     0  0  0   0:0      3:2    +1    3
 3. Atlético                       1   0  0  0   0:0     0  0  1   2:3      2:3    -1    0
 4. Malmö FF                       1   0  0  0   0:0     0  0  1   0:2      0:2    -2    0
~~~



~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. R. Madrid                      1   1  0  0   5:1     0  0  0   0:0      5:1    +4    3
 2. Liverpool                      1   1  0  0   2:1     0  0  0   0:0      2:1    +1    3
 3. Ludogorets                     1   0  0  0   0:0     0  0  1   1:2      1:2    -1    0
 4. FC Basel 1893                  1   0  0  0   0:0     0  0  1   1:5      1:5    -4    0
~~~



~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Zenit                          1   0  0  0   0:0     1  0  0   2:0      2:0    +2    3
 2. AS Monaco                      1   1  0  0   1:0     0  0  0   0:0      1:0    +1    3
 3. Bayer 04 Leverkusen            1   0  0  0   0:0     0  0  1   0:1      0:1    -1    0
 4. Benfica                        1   0  0  1   0:2     0  0  0   0:0      0:2    -2    0
~~~



~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Borussia Dortmund              1   1  0  0   2:0     0  0  0   0:0      2:0    +2    3
 2. Galatasaray                    1   0  1  0   1:1     0  0  0   0:0      1:1          1
 3. Anderlecht                     1   0  0  0   0:0     0  1  0   1:1      1:1          1
 4. Arsenal                        1   0  0  0   0:0     0  0  1   0:2      0:2    -2    0
~~~



~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Roma                           1   1  0  0   5:1     0  0  0   0:0      5:1    +4    3
 2. FC Bayern München              1   1  0  0   1:0     0  0  0   0:0      1:0    +1    3
 3. Manchester City                1   0  0  0   0:0     0  0  1   0:1      0:1    -1    0
 4. CSKA Moskva                    1   0  0  0   0:0     0  0  1   1:5      1:5    -4    0
~~~



~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Barcelona                      1   1  0  0   1:0     0  0  0   0:0      1:0    +1    3
 2. Ajax                           1   0  1  0   1:1     0  0  0   0:0      1:1          1
 3. Paris SG                       1   0  0  0   0:0     0  1  0   1:1      1:1          1
 4. APOEL                          1   0  0  0   0:0     0  0  1   0:1      0:1    -1    0
~~~



~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Chelsea                        1   0  1  0   1:1     0  0  0   0:0      1:1          1
 2. Schalke 04                     1   0  0  0   0:0     0  1  0   1:1      1:1          1
 3. Maribor                        1   0  1  0   1:1     0  0  0   0:0      1:1          1
 4. Sporting Lisboa                1   0  0  0   0:0     0  1  0   1:1      1:1          1
~~~



~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Porto                          1   1  0  0   6:0     0  0  0   0:0      6:0    +6    3
 2. Athletic                       1   0  1  0   0:0     0  0  0   0:0      0:0          1
 3. Shakhtar Donetsk               1   0  0  0   0:0     0  1  0   0:0      0:0          1
 4. BATE Borissow                  1   0  0  0   0:0     0  0  1   0:6      0:6    -6    0
~~~




---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points


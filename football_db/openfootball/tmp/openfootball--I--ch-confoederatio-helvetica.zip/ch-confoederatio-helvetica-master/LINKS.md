# Links

### Super League

Official -> [`sfl.ch`](http://sfl.ch) - Swiss Football League

- 10 Teams (1↓↑)
- 4 x 9 => 36 Rounds
- (1 CL ??, 2 EL) - 2 CL/3.QR, EL/4.QR, EL/3.QR, EL/2.QR -- UEFA Ranking #14


NB: Includes team from Liechtenstein e.g FC Vaduz  (in challenge league ??)

#### Wikipedia

- [Swiss_Super_League](http://en.wikipedia.org/wiki/Swiss_Super_League)
- [2012–13_Swiss_Super_League](http://en.wikipedia.org/wiki/2012–13_Swiss_Super_League)


### Challenge League

- 10 Teams

#### Wikipedia

- [Swiss_Challenge_League](http://en.wikipedia.org/wiki/Swiss_Challenge_League)


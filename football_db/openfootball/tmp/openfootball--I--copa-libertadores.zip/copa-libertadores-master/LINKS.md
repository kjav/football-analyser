
## CONMEBOL Copa Libertadores

Official site - [`www.conmebol.com` -> Copa Libertadores](http://www.conmebol.com)

- 38 Teams (from 11 associations/countries)
- 138 Matches
- every year
- no extra time is played in playoffs -  except for the final!!
- no game for 3rd place


Copa Libertadores 2013

- January 22 - July 24, 2013

Copa Libertadores 2012

- January 24 - July 4, 2012



### Wikipedia

- [2013_Copa_Libertadores](http://en.wikipedia.org/wiki/2013_Copa_Libertadores)
    - [First_Stage](http://en.wikipedia.org/wiki/2013_Copa_Libertadores_First_Stage)
    - [Second_Stage](http://en.wikipedia.org/wiki/2013_Copa_Libertadores_Second_Stage)
- [2012_Copa_Libertadores](http://en.wikipedia.org/wiki/2012_Copa_Libertadores)


### Wikipedia (es)

- [Copa_Libertadores_2013 (es)](http://es.wikipedia.org/wiki/Copa_Libertadores_2013)
- [Copa_Libertadores_2012 (es)](http://es.wikipedia.org/wiki/Copa_Libertadores_2012)


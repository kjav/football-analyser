# Football Players

Free open public domain football data (football.db)
for players (goalkeepers, defenders, midfielders, forwards)

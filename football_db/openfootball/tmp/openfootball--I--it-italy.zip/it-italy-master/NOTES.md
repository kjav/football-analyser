# Notes

## Todos

- [ ] check use 30/8  31/8  13/9 14/9  etc. for dates instead of 30.8., 31.8. etc. yes?


## Weekdays

Weekdays  - move to lang!!!

- domenica/do./dom.  -- Sunday  -- uso do. or dom.??
- lunedì/lun.    -- Monday
- martedì/mar.   -- Tuesday
- mercoledì/mer. -- Wednesday
- giovedì/gio.   -- Thursday
- venerdì/ven.   -- Friday
- sabato/sab.    -- Saturday


## date common short form ?

- use 30/8  31/8  13/9 14/9  etc. yes?


## Links

## Links

### Serie A

Official site -> [`legaseriea.it`](http://legaseriea.it)

- 20 teams
- 2 CL/GR, CL/4.QR, EL/GR, EL/4.QR, EL/3.QR  -- UEFA Ranking #4



#### Wikipedia

- [Serie_A](http://en.wikipedia.org/wiki/Serie_A)


### Notes

#### Three Letter Team Codes

NB: use three letter abbrevations from `legaseriea.it`



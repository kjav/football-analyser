

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Fiorentina                    12   5  0  1  13:3     4  0  2  11:6     24:9   +15   27
 2. Roma                          13   5  1  0  17:6     3  2  2  12:9     29:15  +14   27
 3. Inter                         12   4  1  1   5:4     4  2  0   7:3     12:7    +5   27
 4. Napoli                        12   5  1  0  14:4     2  3  1   8:4     22:8   +14   25
 5. Sassuolo                      12   4  2  0   9:5     2  2  2   5:5     14:10   +4   22
 6. Juventus                      13   4  2  1  10:5     2  1  3   7:6     17:11   +6   21
 7. Milan                         13   4  1  1   8:8     2  1  4   7:9     15:17   -2   20
 8. Atalanta                      12   4  1  0  10:3     1  2  4   3:11    13:14   -1   18
 9. Lazio                         12   5  0  1  12:4     1  0  5   4:16    16:20   -4   18
10. Sampdoria                     12   4  2  1  15:8     0  2  3   4:9     19:17   +2   16
11. Torino                        12   3  2  1  11:7     1  1  4   6:11    17:18   -1   15
12. Palermo                       12   2  2  3   7:9     2  0  3   5:7     12:16   -4   14
13. Empoli                        12   2  1  3   7:9     2  1  3   6:9     13:18   -5   14
14. Chievo                        12   2  2  2   7:4     1  2  3   7:8     14:12   +2   13
15. Genoa                         12   3  1  1   6:4     0  3  4   6:12    12:16   -4   13
16. Udinese                       12   1  2  3   5:7     2  1  3   5:8     10:15   -5   12
17. Frosinone                     12   3  1  2   9:7     0  2  4   3:11    12:18   -6   12
18. Bologna                       13   1  2  4   7:8     2  0  4   6:10    13:18   -5   11
19. Verona                        12   0  3  3   5:10    0  3  3   3:9      8:19  -11    6
20. Carpi                         12   1  2  3   4:6     0  1  5   6:18    10:24  -14    6
~~~




---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points


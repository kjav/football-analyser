# Stats

```
1 leagues
Serie A (it) |  3 events
27 teams
3 events:
#######################
## 2015/16 Serie A  |  20 Teams, 380 Matches, 302 Goals (+0 a.e.t.)
    0 Groups, 38 Rounds (38 Matchdays, 0 K.O.s)
1 (10)  2 (10)  3 (10)  4 (10)  5 (10)  6 (10)  7 (10)  8 (10)  9 (10)  10 (10)  11 (10)  12 (10)  13 (10)  14 (10)  15 (10)  16 (10)  17 (10)  18 (10)  19 (10)  20 (10)  21 (10)  22 (10)  23 (10)  24 (10)  25 (10)  26 (10)  27 (10)  28 (10)  29 (10)  30 (10)  31 (10)  32 (10)  33 (10)  34 (10)  35 (10)  36 (10)  37 (10)  38 (10)  

#######################
## 2014/15 Serie A  |  20 Teams, 379 Matches, 1022 Goals (+0 a.e.t.)
    0 Groups, 38 Rounds (38 Matchdays, 0 K.O.s)
1 (10)  2 (10)  3 (10)  4 (10)  5 (10)  6 (10)  7 (10)  8 (10)  9 (10)  10 (10)  11 (9)  12 (10)  13 (10)  14 (10)  15 (10)  16 (10)  17 (10)  18 (10)  19 (10)  20 (10)  21 (10)  22 (10)  23 (10)  24 (10)  25 (10)  26 (10)  27 (10)  28 (10)  29 (10)  30 (10)  31 (10)  32 (10)  33 (10)  34 (10)  35 (10)  36 (10)  37 (10)  38 (10)  

#######################
## 2013/14 Serie A  |  20 Teams, 380 Matches, 1035 Goals (+0 a.e.t.)
    0 Groups, 38 Rounds (38 Matchdays, 0 K.O.s)
1 (10)  2 (10)  3 (10)  4 (10)  5 (10)  6 (10)  7 (10)  8 (10)  9 (10)  10 (10)  11 (10)  12 (10)  13 (10)  14 (10)  15 (10)  16 (10)  17 (10)  18 (10)  19 (10)  20 (10)  21 (10)  22 (10)  23 (10)  24 (10)  25 (10)  26 (10)  27 (10)  28 (10)  29 (10)  30 (10)  31 (10)  32 (10)  33 (10)  34 (10)  35 (10)  36 (10)  37 (10)  38 (10)  

85 logs:
[warn] Rakefile - 2015-11-22 16:14:08 +0100
[warn] hash reader - found implicit bool (no) for key; adding quotes to turn into string; see yaml.org/refcard.html (path=)
[warn] no country match found for >Bonaire<; skipping line; in [1-codes/fifa]
[warn] no country match found for >Kosovo<; skipping line; in [1-codes/fifa]
[warn] no country match found for >Zanzibar<; skipping line; in [1-codes/fifa]
[warn] no country match found for >Saint-Martin<; skipping line; in [1-codes/fifa]
[warn] no country match found for >Ashmore and Cartier Islands (AU)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Akrotiri (UK)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Burma<; skipping line; in [1-codes/fips]
[warn] no country match found for >Navassa Island (US)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Bassas da India (FR)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Cocos (Keeling) Islands (AU)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Coral Sea Islands (AU)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Jarvis Island (US)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Dhekelia (UK)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Europa Island (FR)<; skipping line; in [1-codes/fips]
[warn] no country match found for >French Polynesia (FR)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Baker Island (US)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Glorioso Islands (FR)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Gaza Strip (PS)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Howland Island (US)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Clipperton Island (FR)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Jan Mayen (NO)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Johnston Atoll (US)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Juan de Nova Island (FR)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Kingman Reef (US)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Kosovo<; skipping line; in [1-codes/fips]
[warn] no country match found for >Palmyra Atoll (US)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Midway Islands (US)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Paracel Islands (CN)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Spratly Islands<; skipping line; in [1-codes/fips]
[warn] no country match found for >South Kuril Islands (RU)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Svalbard (NO)<; skipping line; in [1-codes/fips]
[warn] no country match found for >South Georgia and South Sandwich Islands (UK)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Saint Barthelemy (FR)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Tromelin Island (FR)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Sao Tome and Principe<; skipping line; in [1-codes/fips]
[warn] no country match found for >West Bank<; skipping line; in [1-codes/fips]
[warn] no country match found for >Western Sahara (MA)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Wake Island (US)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Ascension Island<; skipping line; in [1-codes/internet]
[warn] no country match found for >Netherlands Antilles (NL)<; skipping line; in [1-codes/internet]
[warn] no country match found for >Cocos (Keeling) Islands (AU)<; skipping line; in [1-codes/internet]
[warn] no country match found for >French Polynesia<; skipping line; in [1-codes/internet]
[warn] no country match found for >Saint-Pierre and Miquelon<; skipping line; in [1-codes/internet]
[warn] no country match found for >Svalbard and Jan Mayen Islands<; skipping line; in [1-codes/internet]
[warn] no country match found for >Bonaire<; skipping line; in [1-codes/iso]
[warn] no country match found for >Cabo Verde<; skipping line; in [1-codes/iso]
[warn] no country match found for >Cocos (Keeling) Islands (AU)<; skipping line; in [1-codes/iso]
[warn] no country match found for >French Polynesia (FR)<; skipping line; in [1-codes/iso]
[warn] no country match found for >Sao Tome and Principe<; skipping line; in [1-codes/iso]
[warn] no country match found for >Svalbard and Jan Mayen<; skipping line; in [1-codes/iso]
[warn] no country match found for >United States Minor Outlying Islands (US)<; skipping line; in [1-codes/iso]
[warn] no country match found for >Western Sahara<; skipping line; in [1-codes/iso]
[warn] no country match found for >Burma<; skipping line; in [1-codes/motor]
[warn] no country match found for >Zanzibar<; skipping line; in [1-codes/motor]
[warn] no country match found for >Alderney<; skipping line; in [1-codes/motor]
[warn] no country match found for >Transnistria<; skipping line; in [1-codes/motor]
[warn] no country match found for >Kosovo<; skipping line; in [1-codes/motor]
[warn] no country match found for >Western Sahara<; skipping line; in [1-codes/motor]
[warn] city with key milano missing
[warn] city with key milano missing
[warn] city with key roma missing
[warn] city with key roma missing
[warn] city with key genova missing
[warn] city with key genova missing
[warn] city with key torino missing
[warn] city with key torino missing
[warn] city with key napoli missing
[warn] city with key bergamo missing
[warn] city with key verona missing
[warn] city with key verona missing
[warn] city with key firenze missing
[warn] city with key udine missing
[warn] city with key sassuolo missing
[warn] city with key palermo missing
[warn] city with key bologna missing
[warn] city with key carpi missing
[warn] city with key Frosinone missing
[warn] city with key cagliari missing
[warn] city with key parma missing
[warn] city with key catania missing
[warn] city with key livorno missing
[warn] city with key pescara missing
[warn] city with key siena missing
```



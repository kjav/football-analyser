# Notes

## Format

### Date format

Use "american"-style format e.g. (month before day) e.g.:

-  Jul 20  or
-  7/20 etc.

### Matchdays

MLS has no rounds/matchdays, just use regular season as round?
Or use week1, week2 etc.
If using Week 1, Week 2, etc.  when does the week start?  On the mls site it starts on Wednesday(!) - why not??

## Links

### Major League Soccer (MLS)

Official site -> [`www.mlssoccer.com`](http://www.mlssoccer.com)

#### Wikipedia

- [Major_League_Soccer](http://en.wikipedia.org/wiki/Major_League_Soccer)


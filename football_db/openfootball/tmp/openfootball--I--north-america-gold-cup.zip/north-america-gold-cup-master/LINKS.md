
## CONCACAF Gold Cup / Copa de Oro

Official site - [www.goldcup.org](http://www.goldcup.org) or [www.copaoro.org (es)](http://www.copaoro.org)

- 12 teams
    - North American zone   / 3 teams
    - Central American zone / 5 teams
    - Caribbean zone        / 4 teams
- 25 matches
- every two years 


Gold Cup / Copa de Oro 2013

- United States, July 7-28, 2013
- 12th edition

Gold Cup / Copa de Oro 2011

- United States, June 5-25, 2011


### Wikipedia

- [2013_CONCACAF_Gold_Cup](http://en.wikipedia.org/wiki/2013_CONCACAF_Gold_Cup)
- [2011_CONCACAF_Gold_Cup](http://en.wikipedia.org/wiki/2011_CONCACAF_Gold_Cup)


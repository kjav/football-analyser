# Links

- [worldstadiums.com](http://www.worldstadiums.com) -
  more than 11 000 stadiums in over 224 countries

- [stadiumdb.com](http://stadiumdb.com) -
  database counts 1536 stadiums, 492 stadium designs, 156 stadium constructions,
  80 tournament stadiums, 49 historical stadiums



## Wikipedia

- [List_of_soccer_stadiums_in_Canada](http://en.wikipedia.org/wiki/List_of_soccer_stadiums_in_Canada)

## Wikipedia (de)

- [Liste_der_größten_Stadien_in_Österreich (de)](http://de.wikipedia.org/wiki/Liste_der_größten_Stadien_in_Österreich)
- [Liste_der_größten_Fußballstadien_in_Europa (de)](http://de.wikipedia.org/wiki/Liste_der_größten_Fußballstadien_in_Europa)
- [Liste_der_größten_Fußballstadien_der_Welt (de)](http://de.wikipedia.org/wiki/Liste_der_größten_Fußballstadien_der_Welt)

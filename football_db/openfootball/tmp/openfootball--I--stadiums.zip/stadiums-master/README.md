# Stadiums

Free open public domain football stadium data. Example:

~~~
Maracanã|Estádio do Maracanã,   76_935,    Rio de Janeiro, RJ
Corinthians|Arena Corinthians|Arena de São Paulo,  68_000,  São Paulo, SP
Nacional de Brasília|Estádio Nacional (Mané Garrincha)|Mané Garrincha,  70_042,  Brasília, DF
...
~~~


## Questions? Comments?

Send them along to the
[Open Sports & Friends Forum/Mailing List](http://groups.google.com/group/opensport).
Thanks!


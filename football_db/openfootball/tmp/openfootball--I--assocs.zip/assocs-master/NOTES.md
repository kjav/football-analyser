
## FIFA Notes

see en.wikipedia.org/wiki/FIFA

AFC - Asian Football Confederation in Asia and Australia
-- WAFF West_Asian_Football_Federation
see en.wikipedia.org/wiki/West_Asian_Football_Federation

CAF - Confédération Africaine de Football in Africa
CONCACAF - Confederation of North, Central American and Caribbean Association Football in North America and Central America
-- Caribbean Football Union (CFU) - represents all nations in the Caribbean
-- North American Football Union (NAFU) - represents the teams of Canada, Mexico and the USA.
-- Union Centroamericana de Fútbol (UNCAF) - represents the seven nations of Central America
CONMEBOL - Confederación Sudamericana de Fútbol in South America
OFC - Oceania Football Confederation in Oceania
UEFA - Union of European Football Associations in Europe


NB: Australia has been a member of the AFC since 2006

Teams representing transcontinental nations of Russia, Turkey and Kazakhstan are UEFA members,
although the majority of their territory is outside of continental Europe.
Cyprus and Israel are also members for political reasons.
Monaco, Vatican City, Kosovo and Northern Cyprus are not members of UEFA or FIFA,
while Gibraltar is only a provisional member of UEFA.

Guyana and Suriname are CONCACAF members although they are in South America,
as are French Guiana and Guadeloupe despite not being members of FIFA.


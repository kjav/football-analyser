# Football Associations and Governing Bodies

Free open public domain football data (football.db)
for the world's football associations and governing bodies.



## Questions? Comments?

Send them along to the
[Open Sports & Friends Forum/Mailing List](http://groups.google.com/group/opensport).
Thanks!


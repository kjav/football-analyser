# Notes

## Premier League

Official site - [`www.premierleague.com`](http://www.premierleague.com)

- 20 teams
- 380 matches

### Wikipedia

- [Premier_League](http://en.wikipedia.org/wiki/Premier_League)
- [2013–14_Premier_League](http://en.wikipedia.org/wiki/2013–14_Premier_League)
- [2012–13_Premier_League](http://en.wikipedia.org/wiki/2012–13_Premier_League)



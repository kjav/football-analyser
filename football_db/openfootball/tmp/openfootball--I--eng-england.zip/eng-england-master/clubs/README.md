

### Clubs


**[1-premierleague.txt](1-premierleague.txt)** _(19)_ -- 
Chelsea •
Arsenal •
Tottenham Hotspur •
West Ham United •
Crystal Palace •
Manchester United •
Manchester City •
Everton •
Liverpool •
West Bromwich Albion •
Newcastle United •
Stoke City •
Sunderland •
Aston Villa •
Southampton •
Leicester City •
Bournemouth •
Norwich •
Watford



**[2-championship.txt](2-championship.txt)** _(23)_ -- 
Birmingham City •
Blackburn Rovers •
Bolton Wanderers •
Brighton & Hove Albion •
Bristol City •
Burnley •
Derby County •
Huddersfield Town •
Ipswich Town •
Hull City •
Leeds United •
Brentford •
Charlton Athletic •
Queens Park Rangers •
Fulham •
Middlesbrough •
Milton Keynes Dons •
Nottingham Forest •
Preston North End •
Reading •
Rotherham United •
Sheffield Wednesday •
Wolverhampton Wanderers



**[more.txt](more.txt)** _(48)_ -- 
Barnsley •
Blackpool •
Bradford City •
Burton Albion •
Bury •
Chesterfield •
Colchester United •
Coventry City •
Crewe Alexandra •
Doncaster Rovers •
Fleetwood Town •
Gillingham •
Millwall •
Oldham Athletic •
Peterborough United •
Rochdale •
Scunthorpe United •
Sheffield United •
Shrewsbury Town •
Southend United •
Port Vale •
Swindon Town •
Walsall •
Wigan Athletic •
Accrington Stanley •
Bristol Rovers •
Cambridge United •
Carlisle United •
Crawley Town •
Exeter City •
Hartlepool United •
Wycombe Wanderers •
Barnet •
Dagenham & Redbridge •
Leyton Orient •
AFC Wimbledon •
Luton Town •
Mansfield Town •
Morecambe •
Northampton Town •
Notts County •
Oxford United •
Plymouth Argyle •
Portsmouth •
Stevenage •
Yeovil Town •
York City •
Tranmere Rovers



**[wales.txt](wales.txt)** _(3)_ -- 
Swansea _(wal)_ •
Cardiff City _(wal)_ •
Newport County _(wal)_





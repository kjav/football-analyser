

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Manchester United             38  16  0  3  45:19   12  5  2  41:24    86:43  +43   89
 2. Manchester City               38  14  3  2  41:15    9  6  4  25:19    66:34  +32   78
 3. Chelsea                       38  12  5  2  41:16   10  4  5  34:23    75:39  +36   75
 4. Arsenal                       38  11  5  3  47:23   10  5  4  25:14    72:37  +35   73
 5. Tottenham Hotspur             38  11  5  3  29:18   10  4  5  37:28    66:46  +20   72
 6. Everton                       38  12  6  1  33:17    4  9  6  22:23    55:40  +15   63
 7. Liverpool                     38   9  6  4  33:16    7  7  5  38:27    71:43  +28   61
 8. West Bromwich Albion          38   9  4  6  32:25    5  3 11  21:32    53:57   -4   49
 9. Swansea                       38   6  8  5  28:26    5  5  9  19:25    47:51   -4   46
10. West Ham United               38   9  6  4  36:22    3  4 12  11:31    47:53   -6   46
11. Norwich                       38   8  7  4  25:20    2  7 10  16:38    41:58  -17   44
12. Fulham                        38   7  3  9  28:30    4  7  8  22:30    50:60  -10   43
13. Stoke City                    38   7  7  5  21:22    2  8  9  13:23    34:45  -11   42
14. Southampton                   38   6  7  6  26:24    3  7  9  23:36    49:60  -11   41
15. Newcastle United              38   9  1  9  24:31    2  7 10  21:37    45:68  -23   41
16. Aston Villa                   38   5  5  9  23:28    5  6  8  24:43    47:71  -24   41
17. Sunderland                    38   5  8  6  20:19    4  4 11  21:35    41:54  -13   39
18. Wigan Athletic                38   4  6  9  26:39    5  3 11  21:34    47:73  -26   36
19. Reading                       38   4  8  7  23:33    2  2 15  20:40    43:73  -30   28
20. Queens Park Rangers           38   2  8  9  13:28    2  5 12  17:32    30:60  -30   25
~~~




---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points


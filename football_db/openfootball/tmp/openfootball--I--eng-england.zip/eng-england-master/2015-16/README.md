

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Leicester City                13   4  1  1  13:11    4  3  0  15:9     28:20   +8   28
 2. Manchester United             13   4  2  0   9:1     4  1  2  10:8     19:9   +10   27
 3. Manchester City               13   5  0  2  20:9     3  2  1   7:4     27:13  +14   26
 4. Arsenal                       13   3  2  1   8:4     5  0  2  15:7     23:11  +12   26
 5. Tottenham Hotspur             12   3  3  0  10:4     2  3  1  10:6     20:10  +10   21
 6. West Ham United               12   2  2  2  11:10    4  1  1  12:6     23:16   +7   21
 7. Everton                       13   3  2  2  16:11    2  3  1   8:5     24:16   +8   20
 8. Southampton                   13   3  1  3  12:10    2  4  0   7:4     19:14   +5   20
 9. Liverpool                     13   2  2  2   7:9     3  3  1  10:6     17:15   +2   20
10. Crystal Palace                12   2  1  3   6:7     4  0  2   8:5     14:12   +2   19
11. Stoke City                    13   2  1  3   5:7     3  3  1   6:5     11:12   -1   19
12. West Bromwich Albion          13   2  1  4   9:13    3  1  2   3:4     12:17   -5   17
13. Watford                       13   2  2  3   4:6     2  2  2   8:8     12:14   -2   16
14. Swansea                       13   2  3  2   8:9     1  2  3   6:9     14:18   -4   14
15. Chelsea                       13   3  1  3  10:10    1  1  4   7:13    17:23   -6   14
16. Norwich                       13   2  1  3   7:8     1  2  4   9:16    16:24   -8   12
17. Newcastle United              13   1  3  3  11:12    1  1  4   2:13    13:25  -12   10
18. Bournemouth                   13   1  2  3   5:9     1  1  5   9:18    14:27  -13    9
19. Sunderland                    12   1  2  3   7:8     0  1  5   6:18    13:26  -13    6
20. Aston Villa                   13   0  2  4   3:7     1  0  6   7:17    10:24  -14    5
~~~




---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points


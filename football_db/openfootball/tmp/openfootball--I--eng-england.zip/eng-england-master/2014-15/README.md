

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Chelsea                       38  15  4  0  36:9    11  5  3  37:23    73:32  +41   87
 2. Manchester City               38  14  3  2  44:14   10  4  5  39:24    83:38  +45   79
 3. Arsenal                       38  12  5  2  41:14   10  4  5  30:22    71:36  +35   75
 4. Manchester United             38  14  2  3  41:15    6  8  5  21:22    62:37  +25   70
 5. Tottenham Hotspur             38  10  3  6  31:24    9  4  6  27:29    58:53   +5   64
 6. Liverpool                     38  10  5  4  30:20    8  3  8  22:28    52:48   +4   62
 7. Southampton                   38  11  4  4  37:13    7  2 10  17:20    54:33  +21   60
 8. Swansea                       38   9  5  5  27:22    7  3  9  19:27    46:49   -3   56
 9. Stoke City                    38  10  3  6  32:22    5  6  8  16:23    48:45   +3   54
10. Crystal Palace                38   6  3 10  21:27    7  6  6  26:24    47:51   -4   48
11. Everton                       38   7  7  5  27:21    5  4 10  21:29    48:50   -2   47
12. West Ham United               38   9  4  6  25:18    3  7  9  19:29    44:47   -3   47
13. West Bromwich Albion          38   7  4  8  24:26    4  7  8  14:25    38:51  -13   44
14. Leicester City                38   7  5  7  28:22    4  3 12  18:33    46:55   -9   41
15. Newcastle United              38   7  5  7  26:27    3  4 12  14:36    40:63  -23   39
16. Sunderland                    38   4  8  7  16:27    3  9  7  15:26    31:53  -22   38
17. Aston Villa                   38   5  6  8  18:25    5  2 12  13:32    31:57  -26   38
18. Hull City                     38   5  5  9  19:24    3  6 10  14:27    33:51  -18   35
19. Burnley                       38   4  7  8  14:21    3  5 11  14:32    28:53  -25   33
20. Queens Park Rangers           38   6  5  8  23:24    2  1 16  19:49    42:73  -31   30
~~~




---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points




### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Manchester City               38  17  1  1  63:13   10  4  5  39:24   102:37  +65   86
 2. Liverpool                     38  16  1  2  53:18   10  5  4  48:32   101:50  +51   84
 3. Chelsea                       38  15  3  1  43:11   10  4  5  28:16    71:27  +44   82
 4. Arsenal                       38  13  5  1  37:11   11  2  6  32:30    69:41  +28   79
 5. Everton                       38  13  3  3  38:19    8  6  5  23:20    61:39  +22   72
 6. Tottenham Hotspur             38  11  3  5  30:23   10  3  6  25:28    55:51   +4   69
 7. Manchester United             38   9  3  7  29:21   10  4  5  35:22    64:43  +21   64
 8. Southampton                   38   8  6  5  32:23    7  5  7  22:23    54:46   +8   56
 9. Newcastle United              38   8  3  8  23:29    7  1 11  20:31    43:60  -17   49
10. Stoke City                    38   9  7  3  26:17    3  5 11  18:35    44:52   -8   48
11. Crystal Palace                37   7  3  8  15:22    5  4 10  15:24    30:46  -16   43
12. Swansea                       38   6  5  8  33:26    5  4 10  21:28    54:54        42
13. West Ham United               38   7  3  9  25:26    4  4 11  15:25    40:51  -11   40
14. Aston Villa                   38   6  3 10  22:29    4  5 10  17:32    39:61  -22   38
15. Hull City                     38   7  4  8  20:21    3  3 13  18:32    38:53  -15   37
16. West Bromwich Albion          37   4  9  6  24:27    3  6  9  18:30    42:57  -15   36
17. Sunderland                    38   5  3 11  21:27    4  5 10  16:34    37:61  -24   35
18. Fulham                        38   6  3 10  25:34    4  2 13  16:47    41:81  -40   35
19. Norwich                       38   6  6  7  17:18    2  3 14  11:44    28:62  -34   33
20. Cardiff City                  38   5  5  9  20:35    2  4 13  13:39    33:74  -41   30
~~~




---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points


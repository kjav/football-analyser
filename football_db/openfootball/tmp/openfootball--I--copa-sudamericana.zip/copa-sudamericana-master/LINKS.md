
## CONMEBOL Copa Sudamericana

Official site - [`www.conmebol.com` -> Copa Sudamericana](http://www.conmebol.com)

- 47 Teams (from 10 associations/countries)
- 92 Matches
- every year


Copa Sudamericana 2012

- July 24 - December 12, 2012


### Wikipedia

- [2012_Copa_Sudamericana](http://en.wikipedia.org/wiki/2012_Copa_Sudamericana)

### Wikipedia (es)

- [Copa_Sudamericana_2012 (es)](http://es.wikipedia.org/wiki/Copa_Sudamericana_2012)



## Liga MX / Primera División de México

Official Site - [`www.ligamx.net` (es)](http://www.ligamx.net)

- 18 teams


### Wikipedia (es)

- [Primera_División_de_México (es)](http://es.wikipedia.org/wiki/Primera_División_de_México)
- [Torneo_Clausura_2013_(México) (es)](http://es.wikipedia.org/wiki/Torneo_Clausura_2013_(México))
- [Torneo_Apertura_2012_(México) (es)](http://es.wikipedia.org/wiki/Torneo_Apertura_2012_(México))


## Liga de Ascenso de México / Ascenso MX / Segunda División de México

- 15 teams


### Wikipedia (es)

- [Liga_de_Ascenso_de_México (es)](http://es.wikipedia.org/wiki/Liga_de_Ascenso_de_México)


### Wikipedia

- [Ascenso_MX](http://en.wikipedia.org/wiki/Ascenso_MX)



## Sport Newspapers

- [Record (es)](http://www.record.com.mx) (7x week)

## Sport Television Sites

- [Televisa Deportes (es)](http://televisadeportes.esmas.com)


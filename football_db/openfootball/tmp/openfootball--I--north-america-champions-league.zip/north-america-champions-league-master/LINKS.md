
## CONCACAF Champions League

Official site -> [`www.concacaf.com/category/champions-league`](http://www.concacaf.com/category/champions-league)

- 24 Teams
    - 9 North America (4 United States, 4 Mexico, 1 Canada)
    - 12 Central America
    - 3 Caribbean
- every year


Champions League 2013/14

- August 6, 2013 – April, 2014
- 24 Teams (from 11 associations/countries)

Champions League 2012/13

- July 31, 2012 - May 1, 2013
- 24 Teams (from 11 associations/countries)
- 62 Matches

Champions League 2011/12

- July 26, 2011 - April 25, 2012
- 24 Teams  (from 12 associations/countries)
- 78 Matches



### Wikipedia

- [2013–14_CONCACAF_Champions_League](http://en.wikipedia.org/wiki/2013–14_CONCACAF_Champions_League)
- [2012–13_CONCACAF_Champions_League](http://en.wikipedia.org/wiki/2012–13_CONCACAF_Champions_League)
    - [Group_Stage](http://en.wikipedia.org/wiki/2012–13_CONCACAF_Champions_League_Group_Stage)
    - [Championship_Round](http://en.wikipedia.org/wiki/2012–13_CONCACAF_Champions_League_Championship_Round)
- [2011–12_CONCACAF_Champions_League](http://en.wikipedia.org/wiki/2011–12_CONCACAF_Champions_League)

### Wikipedia (es)

- [Concacaf_Liga_Campeones_2012-13 (es)](http://es.wikipedia.org/wiki/Concacaf_Liga_Campeones_2012-13)
- [Concacaf_Liga_Campeones_2011-12 (es)](http://es.wikipedia.org/wiki/Concacaf_Liga_Campeones_2011-12)


# Notes

## Links

### Ligue 1

Official -> [`lfp.fr/ligue1` (fr)](http://lfp.fr/ligue1) or [`ligue1.com`](http://ligue1.com)

- 20 teams
- 2 CL/GR, CL/3.QR, EL/GR, EL/4.QR, EL/3.QR  -- UEFA Ranking #6

# NB: includes club from Monaco

#### Wikipedia

- [Ligue_1](http://en.wikipedia.org/wiki/Ligue_1)
- [2012–13_Ligue_1](http://en.wikipedia.org/wiki/2012–13_Ligue_1)

----

- [Championnat_de_France_de_football (fr)](http://fr.wikipedia.org/wiki/Championnat_de_France_de_football)


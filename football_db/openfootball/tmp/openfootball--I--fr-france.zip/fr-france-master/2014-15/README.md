

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bordeaux                       3   1  0  0   4:1     2  0  0   4:1      8:2    +6    9
 2. AS Saint-Étienne               3   1  1  0   3:1     1  0  0   2:0      5:1    +4    7
 3. LOSC Lille                     3   1  1  0   2:0     1  0  0   1:0      3:0    +3    7
 4. SM Caen                        3   0  0  1   0:1     2  0  0   5:0      5:1    +4    6
 5. Montpellier                    3   1  0  1   2:1     1  0  0   2:0      4:1    +3    6
 6. Paris SG                       3   1  0  0   2:0     0  2  0   2:2      4:2    +2    5
 7. Stade Rennais FC               3   1  0  0   6:2     0  1  1   0:2      6:4    +2    4
 8. FC Nantes                      3   1  0  1   1:1     0  1  0   1:1      2:2          4
 9. SC Bastia                      3   1  1  0   4:3     0  0  1   0:2      4:5    -1    4
10. OGC Nice                       3   1  0  1   4:5     0  1  0   0:0      4:5    -1    4
11. Marseille                      3   0  0  1   0:2     1  1  0   4:3      4:5    -1    4
12. FC Lorient                     3   0  1  0   0:0     1  0  1   2:3      2:3    -1    4
13. Lyon                           3   1  0  1   2:1     0  0  1   1:2      3:3          3
14. Toulouse FC                    3   1  0  0   2:1     0  0  2   2:4      4:5    -1    3
15. RC Lens                        3   0  0  1   0:1     1  0  1   1:1      1:2    -1    3
16. EA Guingamp                    3   0  0  2   0:3     1  0  0   1:0      1:3    -2    3
17. AS Monaco                      3   0  0  1   1:2     1  0  1   2:4      3:6    -3    3
18. FC Metz                        3   0  1  0   1:1     0  1  1   0:2      1:3    -2    2
19. Stade de Reims                 3   0  1  1   2:4     0  0  1   1:3      3:7    -4    1
20. Évian TG                       3   0  1  1   0:3     0  0  1   2:6      2:9    -7    1
~~~




---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points


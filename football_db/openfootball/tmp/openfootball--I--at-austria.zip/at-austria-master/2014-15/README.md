

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. FC RB Salzburg                36  13  1  4  59:19    9  6  3  40:23    99:42  +57   73
 2. SK Rapid Wien                 36  10  5  3  34:13    9  5  4  34:25    68:38  +30   67
 3. SCR Altach                    36  12  3  3  33:16    5  5  8  17:33    50:49   +1   59
 4. SK Sturm Graz                 36   8  6  4  33:23    8  4  6  24:18    57:41  +16   58
 5. Wolfsberger AC                36  11  2  5  27:18    5  2 11  17:32    44:50   -6   52
 6. SV Ried                       36   7  5  6  32:22    5  3 10  17:29    49:51   -2   44
 7. FK Austria Wien               36   7  6  5  26:21    3  7  8  19:30    45:51   -6   43
 8. SV Grödig                     36   6  4  8  25:25    4  3 11  21:40    46:65  -19   37
 9. FC Admira Wacker              36   3  8  7  16:28    4  5  9  16:33    32:61  -29   34
10. SC Wiener Neustadt            36   5  4  9  23:34    2  4 12  14:45    37:79  -42   29
~~~



~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. SV Mattersburg                35  13  1  3  36:13    8  6  4  32:22    68:35  +33   70
 2. FC Liefering                  35   9  3  5  33:29   10  2  6  35:26    68:55  +13   62
 3. LASK Linz                     36  10  6  2  31:15    5  5  8  14:21    45:36   +9   56
 4. Kapfenberger SV               36   7  8  3  23:15    5  5  8  29:30    52:45   +7   49
 5. SKN St. Pölten                36   8  5  5  25:19    5  5  8  14:22    39:41   -2   49
 6. FC Wacker Innsbruck           36   7  4  7  17:16    5  6  7  17:25    34:41   -7   46
 7. SC Austria Lustenau           35   5  4  9  27:32    6  5  6  22:22    49:54   -5   42
 8. Floridsdorfer AC              35   5  7  6  21:24    4  6  7  18:24    39:48   -9   40
 9. SV Horn                       36   8  3  7  18:16    2  5 11  16:34    34:50  -16   38
10. TSV Hartberg                  36   3  6  9  24:38    6  2 10  20:29    44:67  -23   35
~~~




---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points


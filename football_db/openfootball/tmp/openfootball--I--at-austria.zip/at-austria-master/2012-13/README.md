

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. FK Austria Wien               36  12  3  3  42:15   13  4  1  42:16    84:31  +53   82
 2. FC RB Salzburg                36  12  5  1  51:19   10  6  2  40:20    91:39  +52   77
 3. SK Rapid Wien                 36   8  6  4  30:19    8  3  7  27:20    57:39  +18   57
 4. SK Sturm Graz                 36   8  5  5  32:27    5  4  9  16:28    48:55   -7   48
 5. Wolfsberger AC                36   5  6  7  26:27    7  5  6  26:28    52:55   -3   47
 6. SV Ried                       36   8  4  6  33:23    5  3 10  27:36    60:59   +1   46
 7. SC Wiener Neustadt            36   6  6  6  16:21    3  3 12  16:39    32:60  -28   36
 8. FC Wacker Innsbruck           36   7  1 10  21:31    4  2 12  20:44    41:75  -34   36
 9. FC Admira Wacker              36   6  3  9  33:33    3  5 10  14:35    47:68  -21   35
10. SV Mattersburg                36   8  2  8  24:25    1  6 11  12:42    36:67  -31   35
~~~




---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points


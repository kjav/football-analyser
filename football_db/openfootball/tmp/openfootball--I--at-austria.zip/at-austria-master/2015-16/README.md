

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. FK Austria Wien               16   4  3  1  16:11    5  2  1  13:9     29:20   +9   32
 2. FC RB Salzburg                15   5  1  1  23:9     3  3  2  14:11    37:20  +17   28
 3. SK Rapid Wien                 16   5  0  3  16:10    4  1  3  18:12    34:22  +12   28
 4. SK Sturm Graz                 15   4  3  1  16:10    3  0  4   5:8     21:18   +3   24
 5. FC Admira Wacker              16   3  3  2   9:7     3  3  2  12:16    21:23   -2   24
 6. SV Mattersburg                16   5  0  3  13:15    2  1  5  12:19    25:34   -9   22
 7. SV Grödig                     16   5  2  1  17:9     0  2  6   6:15    23:24   -1   19
 8. SCR Altach                    16   5  0  3  11:7     1  1  6   7:15    18:22   -4   19
 9. SV Ried                       16   3  2  3   6:7     0  2  6   8:21    14:28  -14   13
10. Wolfsberger AC                16   3  2  3   9:12    0  1  7   2:10    11:22  -11   12
~~~



~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. FC Wacker Innsbruck           18   3  4  2  16:13    8  0  1  23:9     39:22  +17   37
 2. SKN St. Pölten                18   4  2  3  10:9     7  0  2  19:9     29:18  +11   35
 3. FC Liefering                  18   7  0  2  26:10    3  1  5  14:20    40:30  +10   31
 4. LASK Linz                     17   6  1  2  14:7     3  2  3  12:11    26:18   +8   30
 5. SC Austria Lustenau           18   5  0  4  12:9     4  1  4  13:10    25:19   +6   28
 6. Kapfenberger SV               18   2  1  6  12:20    5  1  3  15:16    27:36   -9   23
 7. SK Austria Klagenfurt         18   4  3  2  17:9     1  4  4  10:18    27:27        22
 8. SC Wiener Neustadt            18   3  2  4   9:11    3  2  4   7:12    16:23   -7   22
 9. SV Austria Salzburg           17   2  2  4  13:18    2  4  3  14:17    27:35   -8   18
10. Floridsdorfer AC              18   0  1  8   7:26    1  1  7   5:14    12:40  -28    5
~~~




---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points


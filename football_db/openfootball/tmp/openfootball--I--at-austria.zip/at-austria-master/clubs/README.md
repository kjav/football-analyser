

### Clubs


**[1-bundesliga.txt](1-bundesliga.txt)** _(15)_ -- 
FK Austria Wien •
FK Austria Wien II •
SK Rapid Wien •
SK Rapid Wien II •
FC Admira Wacker •
FC Admira Wacker II •
SV Mattersburg •
SV Mattersburg II •
FC RB Salzburg •
FC RB Juniors Salzburg •
SV Grödig •
SK Sturm Graz •
Wolfsberger AC •
SV Ried •
SCR Altach



**[2-liga1.txt](2-liga1.txt)** _(11)_ -- 
SC Wiener Neustadt •
FC Wacker Innsbruck •
SC Austria Lustenau •
SKN St. Pölten •
SKN St.Pölten Juniors •
Kapfenberger SV •
SK Austria Klagenfurt •
SV Austria Salzburg •
FC Liefering •
Floridsdorfer AC •
LASK Linz



**[3-bgld.txt](3-bgld.txt)** _(9)_ -- 
SC/ESV Parndorf 1919 •
SV Oberwart •
SV Stegersbach •
SC Pinkafeld •
ASV Draßburg •
SV Wimpassing •
SC Neusiedl am See 1919 •
SC Trausdorf •
SC Ritzing



**[3-ktn.txt](3-ktn.txt)** _(9)_ -- 
Villacher SV •
SAK Klagenfurt •
SV Spittal/Drau •
FC St. Veit •
ATSV Wolfsberg •
FC Lendorf •
ASV Annabichler SV 1923 •
ASKÖ Köttmannsdorf •
VST Völkermarkt



**[3-noe.txt](3-noe.txt)** _(31)_ -- 
SV Horn •
1. SC Sollenau •
SKU Amstetten •
SC Retz •
ATSV Ober-Grafendorf •
ASK Bad Vöslau •
SV Gaflenz •
Ardagger SCU •
SC Rohrendorf •
SV Heiligenkreuz •
SC Krems •
SC Mannsdorf •
SC Leopoldsdorf •
SV Leobendorf •
ASK Kottingsbrunn •
ASV Spratzern •
ASK Ebreichsdorf •
Horn Amateure •
SC Guntersdorf •
SC Echsenbach •
SC St. Martin •
SC Weißenkirchen •
SV Rehberg •
SV Sieghartskirchen •
SV Zwentendorf •
USC Altenwörth •
Grafenwoerth •
USC Kirchberg/W. •
USC Schweiggers •
USV Groß Gerungs •
USV Langenlois



**[3-ooe.txt](3-ooe.txt)** _(10)_ -- 
FC Blau-Weiß Linz •
FC Pasching •
Union Vöcklamarkt •
Union St. Florian •
SV Wallern •
SV Micheldorf •
SK Vorwärts Steyr •
Union Gurten •
ATSV Stadl Paura •
FC Wels



**[3-sbg.txt](3-sbg.txt)** _(8)_ -- 
TSV St. Johann •
TSV Neumarkt am Wallersee •
SV Seekirchen 1945 •
SV Wals-Grünau •
FC Pinzgau Saalfelden •
SAK 1914 •
USC Eugendorf •
SC Golling



**[3-stmk.txt](3-stmk.txt)** _(11)_ -- 
TSV Hartberg •
SC Kalsdorf •
FC Gratkorn •
SV Allerheiligen •
Grazer AK •
DSV Leoben •
Deutschlandsberger SC •
FC Lankowitz •
SV Lafnitz •
FC Gleisdorf 09 •
SC Weiz



**[3-tirol.txt](3-tirol.txt)** _(7)_ -- 
FC Kufstein •
WSG Wattens •
SC Schwaz •
SV Reutte •
FC Kitzbühel •
SVG Reichenau •
SV Innsbruck



**[3-vbg.txt](3-vbg.txt)** _(8)_ -- 
FC Hard •
SC Bregenz •
FC Dornbirn 1913 •
FC Wolfurt •
Dornbirner SV •
FC Höchst •
VfB Hohenems •
FC Lustenau 1907



**[3-wien.txt](3-wien.txt)** _(10)_ -- 
Vienna FC 1894 •
Wr. Sportklub •
SV Schwechat •
Wiener Viktoria •
SC Ostbahn XI •
Team Wiener Linien •
Technopool Admira •
SR Donaufeld •
FC Stadlau •
SC Red Star Penzing



**[history.txt](history.txt)** _(0)_ -- 





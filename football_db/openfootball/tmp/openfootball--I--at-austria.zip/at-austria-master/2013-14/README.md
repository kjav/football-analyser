

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. FC RB Salzburg                36  14  3  1  69:12   11  2  5  41:23   110:35  +75   80
 2. SK Rapid Wien                 36  11  5  2  32:12    6  6  6  31:28    63:40  +23   62
 3. SV Grödig                     36   7  5  6  35:35    8  4  6  33:36    68:71   -3   54
 4. FK Austria Wien               36   8  5  5  33:21    6  6  6  25:23    58:44  +14   53
 5. SK Sturm Graz                 36   6  4  8  27:32    7  5  6  28:24    55:56   -1   48
 6. SV Ried                       36   7  5  6  33:33    3  8  7  22:33    55:66  -11   43
 7. FC Admira Wacker              36   9  3  6  30:23    2  6 10  21:44    51:67  -16   42
 8. Wolfsberger AC                36   6  6  6  27:25    5  2 11  24:38    51:63  -12   41
 9. SC Wiener Neustadt            36   5  5  8  21:36    5  4  9  22:48    43:84  -41   39
10. FC Wacker Innsbruck           36   3  8  7  27:33    2  6 10  15:37    42:70  -28   29
~~~




---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points


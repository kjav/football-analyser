
## Change Team Keys ???


change - do NOT use three letter codes/keys

- ksv  -> kapfenberger|kapfenberg    ??
- vsv  -> villacher|villach          ??
- fac  -> floridsdorfer|floridsdorf  ??
- wac  -> wolfsburger|wolfsburg      ??

Why?  - less conflicts (worldwide) - three letter keys/codes might not be unique worldwide



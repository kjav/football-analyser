

## Campeonato Brasileiro Série A / Brasileirão

Official site - [`www.cbf.com.br/Competições/Série A`](http://www.cbf.com.br/Competições/Série A)

- 20 teams

Campeonato Brasileiro 2013

- 26 de maio - 8 de dezembro


### Wikipedia

- [Campeonato_Brasileiro_de_Futebol_de_2013_-_Série_A (pt)](http://pt.wikipedia.org/wiki/Campeonato_Brasileiro_de_Futebol_de_2013_-_Série_A)
- [Campeonato_Brasileiro_de_Futebol_de_2012_-_Série_A (pt)](http://pt.wikipedia.org/wiki/Campeonato_Brasileiro_de_Futebol_de_2012_-_Série_A)


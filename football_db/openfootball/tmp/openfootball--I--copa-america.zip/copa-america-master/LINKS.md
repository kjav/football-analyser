
## CONMEBOL Copa América

- 12 teams
    - South America (10 teams)
    - Invitees (2 teams) e.g. Japan, Mexico, Costa Rica, etc.
- 26 matches
- every four years (next in 2105 Chile and 2019 in Brazil)
- nb: special copa in 2016 in the United States (centenario de conmebol)


Copa América 2015 Chile

- July 2015


Copa América 2011 Argentina

- July 1 to July 24, 2011


### Wikipedia

- [2015_Copa_América](http://en.wikipedia.org/wiki/2015_Copa_América)
- [2011_Copa_América](http://en.wikipedia.org/wiki/2011_Copa_América)




### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. FC Bayern München             13   7  0  0  28:3     5  1  0  12:2     40:5   +35   37
 2. Borussia Dortmund             13   5  1  0  20:6     4  1  2  16:12    36:18  +18   29
 3. VfL Wolfsburg                 13   6  1  0  20:5     1  2  3   3:10    23:15   +8   24
 4. Borussia M'gladbach           13   4  1  2  12:9     3  0  3  13:10    25:19   +6   22
 5. Hertha BSC                    12   3  1  1   9:6     3  1  3   8:9     17:15   +2   20
 6. Bayer 04 Leverkusen           13   3  1  2   9:8     3  1  3   8:9     17:17        20
 7. Schalke 04                    13   3  2  2   9:10    3  0  3   8:9     17:19   -2   20
 8. 1. FC Köln                    13   2  4  1   5:4     3  0  3  10:14    15:18   -3   19
 9. Hamburger SV                  13   2  2  2   7:6     3  1  3   7:11    14:17   -3   18
10. 1. FSV Mainz 05               13   3  0  4   9:10    2  2  2   9:9     18:19   -1   17
11. FC Ingolstadt 04              12   1  1  3   2:6     3  3  1   5:3      7:9    -2   16
12. Eintracht Frankfurt           13   1  3  2  10:12    2  2  3   7:8     17:20   -3   14
13. Darmstadt                     12   1  3  3   7:11    2  2  1   6:5     13:16   -3   14
14. Werder Bremen                 13   1  0  5   3:12    3  1  3  10:13    13:25  -12   13
15. Hannover 96                   13   1  0  5   6:13    2  2  3   7:11    13:24  -11   11
16. Stuttgart                     13   2  0  5   6:15    1  1  4  11:16    17:31  -14   10
17. FC Augsburg                   13   1  1  5   7:12    1  2  3  10:13    17:25   -8    9
18. 1899 Hoffenheim               12   0  3  3   5:9     1  2  3   7:10    12:19   -7    8
~~~



~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. RB Leipzig                    15   3  2  2  10:9     5  3  0  11:5     21:14   +7   29
 2. SV Sandhausen                 15   3  3  1  11:8     5  1  2  15:8     26:16  +10   28
 3. SC Freiburg                   14   4  2  1  22:13    3  3  1   8:5     30:18  +12   26
 4. FC St. Pauli                  15   5  1  1  12:5     2  4  2   7:8     19:13   +6   26
 5. VfL Bochum                    15   3  3  2  10:7     3  2  2  13:9     23:16   +7   23
 6. Eintr. Braunschweig           14   3  2  3  10:7     3  2  1  12:4     22:11  +11   22
 7. Greuther Fürth                14   4  1  2   8:9     2  2  3  11:14    19:23   -4   21
 8. Heidenheim                    14   4  2  1   8:5     1  3  3   7:6     15:11   +4   20
 9. Karlsruhe                     15   3  2  2  10:7     2  2  4   5:14    15:21   -6   19
10. 1. FC Nürnberg                14   3  4  0  11:7     1  2  4  14:17    25:24   +1   18
11. 1. FC Kaiserslautern          14   2  1  3   4:7     3  2  3  11:11    15:18   -3   18
12. FSV Frankfurt                 14   3  0  5   8:15    2  3  1   5:4     13:19   -6   18
13. Union Berlin                  15   1  5  2  14:16    2  2  3  12:10    26:26        16
14. Bielefeld                     15   0  5  2   2:5     2  5  1  10:8     12:13   -1   16
15. SC Paderborn 07               14   2  3  3   7:11    2  0  4   4:8     11:19   -8   15
16. 1860 München                  15   2  3  2   6:5     0  4  4   4:10    10:15   -5   13
17. Fortuna Düsseldorf            15   3  1  3   8:6     0  3  5   4:14    12:20   -8   13
18. MSV Duisburg                  15   1  4  3   7:14    0  1  6   3:13    10:27  -17    8
~~~



~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Dynamo Dresden                17   7  0  1  20:8     5  4  0  19:10    39:18  +21   40
 2. SG Großaspach                 17   4  4  1  16:11    4  2  2  17:9     33:20  +13   30
 3. 1. FSV Mainz 05 II            17   4  5  0  10:5     4  1  3  13:10    23:15   +8   30
 4. Münster                       17   4  4  1  14:7     3  4  1  10:8     24:15   +9   29
 5. Osnabrück                     17   4  3  1  14:7     3  3  3   8:10    22:17   +5   27
 6. Erzgebirge Aue                17   3  6  0   6:2     3  1  4   6:11    12:13   -1   25
 7. 1. FC Magdeburg               17   6  1  1  16:6     0  5  4   7:11    23:17   +6   24
 8. VfR Aalen                     17   3  5  0   8:4     2  3  4   9:12    17:16   +1   23
 9. Würzburger Kickers            17   1  5  3   7:9     3  4  1   7:2     14:11   +3   21
10. RW Erfurt                     17   5  2  2  13:7     0  4  4   8:13    21:20   +1   21
11. Halle                         17   5  2  2  18:10    1  1  6   5:14    23:24   -1   21
12. Chemnitz                      16   4  2  2  13:9     1  3  4   6:11    19:20   -1   20
13. Holstein Kiel                 17   2  3  3  10:11    3  2  4  12:14    22:25   -3   20
14. Fortuna Köln                  16   4  2  2  14:14    1  2  5   9:18    23:32   -9   19
15. Wiesbaden                     17   3  5  0  15:8     0  4  5   4:15    19:23   -4   18
16. Energie Cottbus               17   1  3  4   8:13    2  5  2   9:10    17:23   -6   17
17. Stutt. Kick.                  17   2  2  4   6:13    2  3  4  11:15    17:28  -11   17
18. Rostock                       17   1  3  4   9:13    1  6  2   7:9     16:22   -6   15
19. Stuttgart II                  17   3  1  5  12:14    1  2  5   8:17    20:31  -11   15
20. Werder Bremen II              17   3  2  4  11:13    1  1  6   9:21    20:34  -14   15
~~~




---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points


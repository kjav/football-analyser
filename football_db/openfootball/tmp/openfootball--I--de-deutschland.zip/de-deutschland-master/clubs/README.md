

### Clubs


**[1-bundesliga.txt](1-bundesliga.txt)** _(22)_ -- 
FC Bayern München •
Borussia Dortmund •
Borussia Dortmund II •
Bayer 04 Leverkusen •
Schalke 04 •
Eintracht Frankfurt •
Hamburger SV •
Borussia M'gladbach •
Hannover 96 •
VfL Wolfsburg •
1. FSV Mainz 05 •
1. FSV Mainz 05 II •
Werder Bremen •
Werder Bremen II •
1899 Hoffenheim •
VfB Stuttgart •
Stuttgart II •
FC Augsburg •
Hertha BSC •
1. FC Köln •
FC Ingolstadt 04 •
SV Darmstadt 98



**[2-bundesliga2.txt](2-bundesliga2.txt)** _(18)_ -- 
SC Paderborn 07 •
SC Freiburg •
Eintr. Braunschweig •
1. FC Nürnberg •
Fortuna Düsseldorf •
Greuther Fürth •
1. FC Kaiserslautern •
FSV Frankfurt •
1860 München •
Union Berlin •
VfL Bochum •
FC St. Pauli •
SV Sandhausen •
Karlsruhe •
Heidenheim •
RB Leipzig •
MSV Duisburg •
Bielefeld



**[bb_brandenburg.txt](bb_brandenburg.txt)** _(4)_ -- 
Energie Cottbus •
Babelsberg •
FSV Optik Rathenow •
SV Falkensee-Finkenkrug



**[be_berlin.txt](be_berlin.txt)** _(6)_ -- 
Tasmania 1900 Berlin •
Tennis Borussia Berlin •
Blau-Weiß 90 Berlin •
BFC Dynamo •
Berliner AK 07 •
FC Viktoria 1889 Berlin



**[bw_baden_wuerttemberg.txt](bw_baden_wuerttemberg.txt)** _(12)_ -- 
VfR Aalen •
Stutt. Kick. •
SG Großaspach •
SV Waldhof Mannheim •
SSV Ulm 1846 •
FC Nöttingen •
Bahlinger SC •
Neckarsulmer Sport-Union •
Offenburger FV •
FC-Astoria Walldorf •
SV Waldkirch •
SSV Reutlingen 05



**[by_bayern.txt](by_bayern.txt)** _(6)_ -- 
Jahn Regensburg •
TSV 1860 Rosenheim •
Wacker Burghausen •
SpVgg Unterhaching •
Würzburger Kickers •
FV Illertissen



**[hb_bremen.txt](hb_bremen.txt)** _(3)_ -- 
SG Aumund-Vegesack •
FC Oberneuland •
Bremer SV



**[he_hessen.txt](he_hessen.txt)** _(3)_ -- 
Wiesbaden •
Kickers Offenbach •
KSV Hessen Kassel



**[hh_hamburg.txt](hh_hamburg.txt)** _(3)_ -- 
SC Victoria Hamburg •
USC Paloma Hamburg •
HSV Barmbek-Uhlenhorst



**[mv_mecklenburg_vorpommern.txt](mv_mecklenburg_vorpommern.txt)** _(4)_ -- 
Hansa Rostock •
TSG Neustrelitz •
FC Schönberg 95 •
1. FC Neubrandenburg 04



**[ni_niedersachsen.txt](ni_niedersachsen.txt)** _(6)_ -- 
VfL Osnabrück •
SV Wilhelmshaven •
BSV Schwarz-Weiß Rehden •
TSV Havelse •
FT Braunschweig •
SV Meppen



**[nw_nordrhein_westfalen.txt](nw_nordrhein_westfalen.txt)** _(16)_ -- 
Münster •
Aachen •
Fortuna Köln •
FC Viktoria Köln •
Rot-Weiss Essen •
Rot-Weiß Oberhausen •
Wuppertaler SV •
KFC Uerdingen 05 •
SG Wattenscheid 09 •
SF Baumberg •
SF Siegen •
SF Lotte •
SV Lippstadt 08 •
SC Wiedenbrück •
FC Hennef 05 •
TuS Erndtebrück



**[rp_rheinland_pfalz.txt](rp_rheinland_pfalz.txt)** _(7)_ -- 
Eintracht Trier •
TSG Pfeddersheim •
SV Roßbach/Verscheid •
Wormatia Worms •
SV Alemannia Waldalgesheim •
FSV Salmrohr •
FK Pirmasens



**[sh_schleswig_holstein.txt](sh_schleswig_holstein.txt)** _(3)_ -- 
Holstein Kiel •
VfR Neumünster •
VfB Lübeck



**[sl_saarland.txt](sl_saarland.txt)** _(4)_ -- 
Saarbrücken •
SV Elversberg •
Borussia Neunkirchen •
FC Homburg



**[sn_sachsen.txt](sn_sachsen.txt)** _(4)_ -- 
Erzgebirge Aue •
Dynamo Dresden •
Chemnitzer FC •
VfB Leipzig



**[st_sachsen_anhalt.txt](st_sachsen_anhalt.txt)** _(2)_ -- 
Hallescher FC •
1. FC Magdeburg



**[th_thueringen.txt](th_thueringen.txt)** _(3)_ -- 
Rot-Weiß Erfurt •
SV Schott Jena •
FC Carl Zeiss Jena





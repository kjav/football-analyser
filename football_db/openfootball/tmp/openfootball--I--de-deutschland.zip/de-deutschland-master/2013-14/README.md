

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. FC Bayern München             34  15  1  1  48:15   14  2  1  46:8     94:23  +71   90
 2. Borussia Dortmund             34  11  2  4  41:19   11  3  3  39:19    80:38  +42   71
 3. Schalke 04                    34  12  2  3  37:16    7  5  5  26:27    63:43  +20   64
 4. Bayer 04 Leverkusen           34  10  3  4  35:22    9  1  7  25:19    60:41  +19   61
 5. VfL Wolfsburg                 34  11  3  3  37:22    7  3  7  26:28    63:50  +13   60
 6. Borussia M'gladbach           34  11  3  3  38:17    5  4  8  22:26    60:43  +17   55
 7. 1. FSV Mainz 05               34  10  3  4  28:17    6  2  9  24:37    52:54   -2   53
 8. FC Augsburg                   34   9  3  5  27:22    6  4  7  20:25    47:47        52
 9. 1899 Hoffenheim               34   7  6  4  43:31    4  5  8  29:39    72:70   +2   44
10. Hannover 96                   34   8  5  4  27:25    4  1 12  19:34    46:59  -13   42
11. Hertha BSC                    34   6  3  8  20:24    5  5  7  20:24    40:48   -8   41
12. Werder Bremen                 34   7  5  5  21:29    4  3 10  21:36    42:65  -23   41
13. Eintracht Frankfurt           34   5  5  7  22:24    4  4  9  18:33    40:57  -17   36
14. SC Freiburg                   34   6  4  7  25:30    3  4 10  17:31    42:61  -19   35
15. Stuttgart                     34   5  4  8  28:28    3  3 11  20:34    48:62  -14   31
16. Hamburger SV                  34   6  2  9  24:34    2  3 12  27:41    51:75  -24   29
17. 1. FC Nürnberg                34   3  5  9  16:32    2  6  9  21:38    37:70  -33   26
18. Eintr. Braunschweig           34   5  3  9  18:24    1  4 12  11:36    29:60  -31   25
~~~



~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. 1. FC Köln                    34  10  4  3  44:37   10  5  2  52:26    96:63  +33   69
 2. SC Paderborn 07               34  11  4  2  43:15    9  4  4  63:41   106:56  +50   68
 3. Greuther Fürth                34   9  3  5  40:46    7  6  4  63:40   103:86  +17   57
 4. Fortuna Düsseldorf            34   8  4  5  43:36    6  6  5  50:37    93:73  +20   52
 5. Karlsruhe                     34   7  7  3  46:49    5  6  6  45:28    91:77  +14   49
 6. 1860 München                  34   7  3  7  32:48    6  6  5  47:41    79:89  -10   48
 7. 1. FC Kaiserslautern          34   8  5  4  50:46    5  4  8  21:35    71:81  -10   48
 8. FC Ingolstadt 04              34   5  3  9  36:48    7  8  2  44:30    80:78   +2   47
 9. FC St. Pauli                  34   4  5  8  37:53    9  3  5  56:41    93:94   -1   47
10. VfR Aalen                     34   6  6  5  39:44    6  4  7  45:41    84:85   -1   46
11. FSV Frankfurt                 34   7  5  5  36:51    5  3  9  52:40    88:91   -3   44
12. Union Berlin                  34   7  6  4  40:48    4  4  9  48:44    88:92   -4   43
13. SV Sandhausen                 34   7  4  6  35:48    5  3  9  12:29    47:77  -30   43
14. VfL Bochum                    34   6  3  8  35:38    6  3  8  42:33    77:71   +6   42
15. Erzgebirge Aue                34   9  3  5  37:22    2  5 10  45:49    82:71  +11   41
16. Bielefeld                     34   4  6  7  36:52    6  1 10  51:46    87:98  -11   37
17. Dynamo Dresden                34   5  8  4  37:50    1  7  9  27:48    64:98  -34   33
18. Energie Cottbus               34   4  3 10  31:60    1  4 12  28:48    59:108 -49   22
~~~




---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points


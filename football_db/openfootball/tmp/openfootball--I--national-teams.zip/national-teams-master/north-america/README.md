

### National Teams


**[teams.txt](teams.txt)** _(3)_ -- 
Mexico _(mx)_ •
United States _(us)_ •
Canada _(ca)_







### National Teams


**[teams.txt](teams.txt)** _(32)_ -- 
Kazakhstan _(kz)_ •
Afghanistan _(af)_ •
Bangladesh _(bd)_ •
Bhutan _(bt)_ •
India _(in)_ •
Kyrgyzstan _(kg)_ •
Maldives _(mv)_ •
Nepal _(np)_ •
Pakistan _(pk)_ •
Sri Lanka _(lk)_ •
Tajikistan _(tj)_ •
Turkmenistan _(tm)_ •
Uzbekistan _(uz)_ •
China _(cn)_ •
Hong Kong _(hk)_ •
Japan _(jp)_ •
North Korea _(kp)_ •
South Korea _(kr)_ •
Macau _(mo)_ •
Mongolia _(mn)_ •
Taiwan _(tw)_ •
Brunei _(bn)_ •
Cambodia _(kh)_ •
Indonesia _(id)_ •
Laos _(la)_ •
Malaysia _(my)_ •
Myanmar _(mm)_ •
Philippines _(ph)_ •
Singapore _(sg)_ •
Thailand _(th)_ •
Timor-Leste _(tl)_ •
Vietnam _(vn)_







### National Teams


**[teams.txt](teams.txt)** _(17)_ -- 
Australia _(au)_ •
Guam _(gu)_ •
Northern Mariana Islands _(mp)_ •
American Samoa _(as)_ •
Cook Islands _(ck)_ •
Fiji _(fj)_ •
New Caledonia _(nc)_ •
New Zealand _(nz)_ •
Papua New Guinea _(pg)_ •
Samoa _(ws)_ •
Solomon Islands _(sb)_ •
Tahiti _(pf)_ •
Tonga _(to)_ •
Vanuatu _(vu)_ •
Kiribati _(ki)_ •
Niue _(nu)_ •
Tuvalu _(tv)_





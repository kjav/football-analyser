

### National Teams


**[teams.txt](teams.txt)** _(56)_ -- 
Algeria _(dz)_ •
Egypt _(eg)_ •
Morocco _(ma)_ •
Libya _(ly)_ •
Tunisia _(tn)_ •
Cape Verde _(cv)_ •
Gambia _(gm)_ •
Guinea _(gn)_ •
Guinea-Bissau _(gw)_ •
Liberia _(lr)_ •
Mali _(ml)_ •
Mauritania _(mr)_ •
Senegal _(sn)_ •
Sierra Leone _(sl)_ •
Benin _(bj)_ •
Burkina Faso _(bf)_ •
Côte d'Ivoire _(ci)_ •
Ghana _(gh)_ •
Niger _(ne)_ •
Nigeria _(ng)_ •
Togo _(tg)_ •
Cameroon _(cm)_ •
Central African Republic _(cf)_ •
Chad _(td)_ •
Congo _(cg)_ •
Congo DR _(cd)_ •
Equatorial Guinea _(gq)_ •
Gabon _(ga)_ •
São Tomé and Príncipe _(st)_ •
Burundi _(bi)_ •
Djibouti _(dj)_ •
Eritrea _(er)_ •
Ethiopia _(et)_ •
Kenya _(ke)_ •
Rwanda _(rw)_ •
Somalia _(so)_ •
South Sudan _(ss)_ •
Sudan _(sd)_ •
Tanzania _(tz)_ •
Uganda _(ug)_ •
Zanzibar _(tz)_ •
Angola _(ao)_ •
Botswana _(bw)_ •
Comoros _(km)_ •
Lesotho _(ls)_ •
Mauritius _(mu)_ •
Madagascar _(mg)_ •
Malawi _(mw)_ •
Mozambique _(mz)_ •
Namibia _(na)_ •
Seychelles _(sc)_ •
South Africa _(za)_ •
Swaziland _(sz)_ •
Zambia _(zm)_ •
Zimbabwe _(zw)_ •
Réunion _(re)_





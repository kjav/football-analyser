

### National Teams


**[teams.txt](teams.txt)** _(52)_ -- 
Austria _(at)_ •
Belgium _(be)_ •
Cyprus _(cy)_ •
Germany _(de)_ •
Estonia _(ee)_ •
Spain _(es)_ •
Finland _(fi)_ •
France _(fr)_ •
Greece _(gr)_ •
Ireland _(ie)_ •
Italy _(it)_ •
Luxembourg _(lu)_ •
Malta _(mt)_ •
Netherlands _(nl)_ •
Portugal _(pt)_ •
Slovakia _(sk)_ •
Slovenia _(si)_ •
Bulgaria _(bg)_ •
Denmark _(dk)_ •
Latvija _(lv)_ •
Lithuania _(lt)_ •
Poland _(pl)_ •
Romania _(ro)_ •
Sweden _(se)_ •
Czech Republic _(cz)_ •
Hungary _(hu)_ •
Andorra _(ad)_ •
Albania _(al)_ •
Belarus _(by)_ •
Switzerland _(ch)_ •
Croatia _(hr)_ •
Serbia _(rs)_ •
Russia _(ru)_ •
Turkey _(tr)_ •
Ukraine _(ua)_ •
Macedonia _(mk)_ •
Norway _(no)_ •
Iceland _(is)_ •
Bosnia-Herzegovina _(ba)_ •
Liechtenstein _(li)_ •
Montenegro _(me)_ •
Moldova _(md)_ •
San Marino _(sm)_ •
Georgia _(ge)_ •
Armenia _(am)_ •
Azerbaijan _(az)_ •
England _(eng)_ •
Scotland _(sco)_ •
Wales _(wal)_ •
Northern Ireland _(nir)_ •
Faroe Islands _(fo)_ •
Gibraltar _(gi)_





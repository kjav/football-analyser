

### National Teams


**[africa/teams.txt](africa/teams.txt)** _(56)_ -- 
Algeria _(dz)_ •
Egypt _(eg)_ •
Morocco _(ma)_ •
Libya _(ly)_ •
Tunisia _(tn)_ •
Cape Verde _(cv)_ •
Gambia _(gm)_ •
Guinea _(gn)_ •
Guinea-Bissau _(gw)_ •
Liberia _(lr)_ •
Mali _(ml)_ •
Mauritania _(mr)_ •
Senegal _(sn)_ •
Sierra Leone _(sl)_ •
Benin _(bj)_ •
Burkina Faso _(bf)_ •
Côte d'Ivoire _(ci)_ •
Ghana _(gh)_ •
Niger _(ne)_ •
Nigeria _(ng)_ •
Togo _(tg)_ •
Cameroon _(cm)_ •
Central African Republic _(cf)_ •
Chad _(td)_ •
Congo _(cg)_ •
Congo DR _(cd)_ •
Equatorial Guinea _(gq)_ •
Gabon _(ga)_ •
São Tomé and Príncipe _(st)_ •
Burundi _(bi)_ •
Djibouti _(dj)_ •
Eritrea _(er)_ •
Ethiopia _(et)_ •
Kenya _(ke)_ •
Rwanda _(rw)_ •
Somalia _(so)_ •
South Sudan _(ss)_ •
Sudan _(sd)_ •
Tanzania _(tz)_ •
Uganda _(ug)_ •
Zanzibar _(tz)_ •
Angola _(ao)_ •
Botswana _(bw)_ •
Comoros _(km)_ •
Lesotho _(ls)_ •
Mauritius _(mu)_ •
Madagascar _(mg)_ •
Malawi _(mw)_ •
Mozambique _(mz)_ •
Namibia _(na)_ •
Seychelles _(sc)_ •
South Africa _(za)_ •
Swaziland _(sz)_ •
Zambia _(zm)_ •
Zimbabwe _(zw)_ •
Réunion _(re)_



**[asia/teams.txt](asia/teams.txt)** _(32)_ -- 
Kazakhstan _(kz)_ •
Afghanistan _(af)_ •
Bangladesh _(bd)_ •
Bhutan _(bt)_ •
India _(in)_ •
Kyrgyzstan _(kg)_ •
Maldives _(mv)_ •
Nepal _(np)_ •
Pakistan _(pk)_ •
Sri Lanka _(lk)_ •
Tajikistan _(tj)_ •
Turkmenistan _(tm)_ •
Uzbekistan _(uz)_ •
China _(cn)_ •
Hong Kong _(hk)_ •
Japan _(jp)_ •
North Korea _(kp)_ •
South Korea _(kr)_ •
Macau _(mo)_ •
Mongolia _(mn)_ •
Taiwan _(tw)_ •
Brunei _(bn)_ •
Cambodia _(kh)_ •
Indonesia _(id)_ •
Laos _(la)_ •
Malaysia _(my)_ •
Myanmar _(mm)_ •
Philippines _(ph)_ •
Singapore _(sg)_ •
Thailand _(th)_ •
Timor-Leste _(tl)_ •
Vietnam _(vn)_



**[caribbean/teams.txt](caribbean/teams.txt)** _(28)_ -- 
Anguilla _(ai)_ •
Antigua and Barbuda _(ag)_ •
Aruba _(aw)_ •
Bahamas _(bs)_ •
Barbados _(bb)_ •
Bermuda _(bm)_ •
British Virgin Islands _(vg)_ •
Cayman Islands _(ky)_ •
Cuba _(cu)_ •
Curaçao _(cw)_ •
Dominica _(dm)_ •
Dominican Republic _(do)_ •
Grenada _(gd)_ •
Haiti _(ht)_ •
Jamaica _(jm)_ •
Montserrat _(ms)_ •
Puerto Rico _(pr)_ •
Saint Kitts and Nevis _(kn)_ •
Saint Lucia _(lc)_ •
Saint Vincent and the Grenadines _(vc)_ •
Trinidad and Tobago _(tt)_ •
Turks and Caicos Islands _(tc)_ •
United States Virgin Islands _(vi)_ •
Bonaire _(nl)_ •
Guadeloupe _(gp)_ •
Martinique _(mq)_ •
Saint Martin _(mf)_ •
Sint Maarten _(nl)_



**[central-america/teams.txt](central-america/teams.txt)** _(7)_ -- 
Honduras _(hn)_ •
Costa Rica _(cr)_ •
El Salvador _(sv)_ •
Panama _(pa)_ •
Guatemala _(gt)_ •
Belize _(bz)_ •
Nicaragua _(ni)_



**[europe/teams.txt](europe/teams.txt)** _(52)_ -- 
Austria _(at)_ •
Belgium _(be)_ •
Cyprus _(cy)_ •
Germany _(de)_ •
Estonia _(ee)_ •
Spain _(es)_ •
Finland _(fi)_ •
France _(fr)_ •
Greece _(gr)_ •
Ireland _(ie)_ •
Italy _(it)_ •
Luxembourg _(lu)_ •
Malta _(mt)_ •
Netherlands _(nl)_ •
Portugal _(pt)_ •
Slovakia _(sk)_ •
Slovenia _(si)_ •
Bulgaria _(bg)_ •
Denmark _(dk)_ •
Latvija _(lv)_ •
Lithuania _(lt)_ •
Poland _(pl)_ •
Romania _(ro)_ •
Sweden _(se)_ •
Czech Republic _(cz)_ •
Hungary _(hu)_ •
Andorra _(ad)_ •
Albania _(al)_ •
Belarus _(by)_ •
Switzerland _(ch)_ •
Croatia _(hr)_ •
Serbia _(rs)_ •
Russia _(ru)_ •
Turkey _(tr)_ •
Ukraine _(ua)_ •
Macedonia _(mk)_ •
Norway _(no)_ •
Iceland _(is)_ •
Bosnia-Herzegovina _(ba)_ •
Liechtenstein _(li)_ •
Montenegro _(me)_ •
Moldova _(md)_ •
San Marino _(sm)_ •
Georgia _(ge)_ •
Armenia _(am)_ •
Azerbaijan _(az)_ •
England _(eng)_ •
Scotland _(sco)_ •
Wales _(wal)_ •
Northern Ireland _(nir)_ •
Faroe Islands _(fo)_ •
Gibraltar _(gi)_



**[middle-east/teams.txt](middle-east/teams.txt)** _(14)_ -- 
Israel _(il)_ •
Bahrain _(bh)_ •
Iran _(ir)_ •
Iraq _(iq)_ •
Jordan _(jo)_ •
Kuwait _(kw)_ •
Lebanon _(lb)_ •
Oman _(om)_ •
Palestine _(ps)_ •
Qatar _(qa)_ •
Saudi Arabia _(sa)_ •
Syria _(sy)_ •
United Arab Emirates _(ae)_ •
Yemen _(ye)_



**[north-america/teams.txt](north-america/teams.txt)** _(3)_ -- 
Mexico _(mx)_ •
United States _(us)_ •
Canada _(ca)_



**[pacific/teams.txt](pacific/teams.txt)** _(17)_ -- 
Australia _(au)_ •
Guam _(gu)_ •
Northern Mariana Islands _(mp)_ •
American Samoa _(as)_ •
Cook Islands _(ck)_ •
Fiji _(fj)_ •
New Caledonia _(nc)_ •
New Zealand _(nz)_ •
Papua New Guinea _(pg)_ •
Samoa _(ws)_ •
Solomon Islands _(sb)_ •
Tahiti _(pf)_ •
Tonga _(to)_ •
Vanuatu _(vu)_ •
Kiribati _(ki)_ •
Niue _(nu)_ •
Tuvalu _(tv)_



**[south-america/teams.txt](south-america/teams.txt)** _(13)_ -- 
Argentina _(ar)_ •
Brazil _(br)_ •
Chile _(cl)_ •
Paraguay _(py)_ •
Uruguay _(uy)_ •
Colombia _(co)_ •
Ecuador _(ec)_ •
Peru _(pe)_ •
Venezuela _(ve)_ •
Bolivia _(bo)_ •
Guyana _(gy)_ •
Suriname _(sr)_ •
French Guiana _(gf)_



**[teams_history.txt](teams_history.txt)** _(7)_ -- 
Czechoslovakia (-1992) _(cz)_ •
West Germany (-1989) _(de)_ •
East Germany (-1989) _(de)_ •
Soviet Union (-1991) _(ru)_ •
Yugoslavia (-2003) _(rs)_ •
Dutch East Indies (-1945) _(id)_ •
Zaire (-????) _(cd)_





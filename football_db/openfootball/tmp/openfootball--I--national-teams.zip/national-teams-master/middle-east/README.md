

### National Teams


**[teams.txt](teams.txt)** _(14)_ -- 
Israel _(il)_ •
Bahrain _(bh)_ •
Iran _(ir)_ •
Iraq _(iq)_ •
Jordan _(jo)_ •
Kuwait _(kw)_ •
Lebanon _(lb)_ •
Oman _(om)_ •
Palestine _(ps)_ •
Qatar _(qa)_ •
Saudi Arabia _(sa)_ •
Syria _(sy)_ •
United Arab Emirates _(ae)_ •
Yemen _(ye)_







### National Teams


**[teams.txt](teams.txt)** _(13)_ -- 
Argentina _(ar)_ •
Brazil _(br)_ •
Chile _(cl)_ •
Paraguay _(py)_ •
Uruguay _(uy)_ •
Colombia _(co)_ •
Ecuador _(ec)_ •
Peru _(pe)_ •
Venezuela _(ve)_ •
Bolivia _(bo)_ •
Guyana _(gy)_ •
Suriname _(sr)_ •
French Guiana _(gf)_





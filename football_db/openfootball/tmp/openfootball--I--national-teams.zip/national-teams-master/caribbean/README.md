

### National Teams


**[teams.txt](teams.txt)** _(28)_ -- 
Anguilla _(ai)_ •
Antigua and Barbuda _(ag)_ •
Aruba _(aw)_ •
Bahamas _(bs)_ •
Barbados _(bb)_ •
Bermuda _(bm)_ •
British Virgin Islands _(vg)_ •
Cayman Islands _(ky)_ •
Cuba _(cu)_ •
Curaçao _(cw)_ •
Dominica _(dm)_ •
Dominican Republic _(do)_ •
Grenada _(gd)_ •
Haiti _(ht)_ •
Jamaica _(jm)_ •
Montserrat _(ms)_ •
Puerto Rico _(pr)_ •
Saint Kitts and Nevis _(kn)_ •
Saint Lucia _(lc)_ •
Saint Vincent and the Grenadines _(vc)_ •
Trinidad and Tobago _(tt)_ •
Turks and Caicos Islands _(tc)_ •
United States Virgin Islands _(vi)_ •
Bonaire _(nl)_ •
Guadeloupe _(gp)_ •
Martinique _(mq)_ •
Saint Martin _(mf)_ •
Sint Maarten _(nl)_





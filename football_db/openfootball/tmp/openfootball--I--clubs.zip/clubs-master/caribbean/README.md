

### Clubs


**[clubs.txt](clubs.txt)** _(5)_ -- 
Caledonia _(tt)_ •
W Connection _(tt)_ •
Puerto Rico Islanders _(pr)_ •
Tempête _(ht)_ •
Valencia _(ht)_





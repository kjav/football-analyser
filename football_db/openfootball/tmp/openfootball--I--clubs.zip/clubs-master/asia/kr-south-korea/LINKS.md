## Links

### K-League

- 14 teams

#### Wikipedia

- [2013_K_League_Classic](http://en.wikipedia.org/wiki/2013_K_League_Classic)


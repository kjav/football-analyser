

### Clubs


**[clubs.txt](clubs.txt)** _(9)_ -- 
Astana _(kz)_ •
FC Aktobe _(kz)_ •
Shakhter _(kz)_ •
FC Tobol Kostanay _(kz)_ •
FC Irtysh Pavlodar _(kz)_ •
FC Ordabasy Shymkent _(kz)_ •
FC Atyrau _(kz)_ •
FC Zhetysu Taldykorgan _(kz)_ •
FC Okzhetpes Kokshetau _(kz)_



**[cn-china/clubs.txt](cn-china/clubs.txt)** _(1)_ -- 
Guangzhou Evergrande



**[jp-japan/clubs.txt](jp-japan/clubs.txt)** _(18)_ -- 
Albirex Niigata •
Kashima Antlers •
Omiya Ardija •
Cerezo Osaka •
Yokohama F. Marinos •
Kawasaki Frontale •
Nagoya Grampus •
Júbilo Iwata •
Oita Trinita •
Urawa Red Diamonds •
Kashiwa Reysol •
Shimizu S-Pulse •
Sagan Tosu •
Sanfrecce Hiroshima •
Shonan Bellmare •
FC Tokyo •
Vegalta Sendai •
Ventforet Kofu



**[kr-south-korea/clubs.txt](kr-south-korea/clubs.txt)** _(14)_ -- 
Busan I'Park •
Chunnam Dragons •
Daegu FC •
Daejeon Citizen •
Gangwon FC •
Gyeongnam FC •
Incheon United •
Jeju United •
Jeonbuk Motors •
Pohang Steelers •
Seongnam Ilhwa Chunma •
FC Seoul •
Suwon Bluewings •
Ulsan Hyundai





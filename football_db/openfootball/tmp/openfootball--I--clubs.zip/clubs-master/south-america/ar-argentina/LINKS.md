
## Primera División de Argentina

Official site -> [`www.afa.org.ar`](http://www.afa.org.ar)

- 20 teams


### Wikipedia

- [Primera_División_de_Argentina (es)](http://es.wikipedia.org/wiki/Primera_División_de_Argentina)
- [Campeonato_de_Primera_División_2012/13_(Argentina) (es)](http://es.wikipedia.org/wiki/Campeonato_de_Primera_División_2012/13_(Argentina))


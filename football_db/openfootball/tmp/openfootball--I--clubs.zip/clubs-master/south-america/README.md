

### Clubs


**[ar-argentina/clubs.txt](ar-argentina/clubs.txt)** _(20)_ -- 
All Boys •
Argentions •
Boca •
River •
San Lorenzo •
Vélez •
Tigre •
Independiente •
Racing •
Quilmes •
Lanús •
Arsenal •
Estudiantes •
Colón •
Unión •
Newell's •
At. de Rafaela •
Belgrano •
Godoy Cruz •
San Martín



**[bo-bolivia/clubs.txt](bo-bolivia/clubs.txt)** _(5)_ -- 
Bolívar _(bo)_ •
Strongest _(bo)_ •
Real Potosí _(bo)_ •
San José _(bo)_ •
Oriente Petrolero _(bo)_



**[cl-chile/clubs.txt](cl-chile/clubs.txt)** _(5)_ -- 
Universidad de Chile _(cl)_ •
Universidad Católica _(cl)_ •
Unión Española _(cl)_ •
Huachipato _(cl)_ •
Iquique _(cl)_



**[clubs.txt](clubs.txt)** _(1)_ -- 
Alpha United _(gy)_



**[co-colombia/clubs.txt](co-colombia/clubs.txt)** _(6)_ -- 
Millonarios Bogotá •
Santa Fe •
At. Nacional •
Junior •
Once Caldas •
Deportes Tolima



**[ec-ecuador/clubs.txt](ec-ecuador/clubs.txt)** _(6)_ -- 
Deportivo Quito _(ec)_ •
El Nacional _(ec)_ •
LDU Quito _(ec)_ •
CS Emelec _(ec)_ •
Barcelona _(ec)_ •
LDU Loja _(ec)_



**[pe-peru/clubs.txt](pe-peru/clubs.txt)** _(6)_ -- 
Alianza Lima _(pe)_ •
Sporting Cristal _(pe)_ •
Juan Aurich _(pe)_ •
Sport Huancayo _(pe)_ •
Real Garcilaso _(pe)_ •
Universidad César Vallejo _(pe)_



**[py-paraguay/clubs.txt](py-paraguay/clubs.txt)** _(4)_ -- 
Club Libertad Asunción _(py)_ •
Olimpia _(py)_ •
Nacional _(py)_ •
Cerro Porteño _(py)_



**[uy-uruguay/clubs.txt](uy-uruguay/clubs.txt)** _(16)_ -- 
Liverpool •
Nacional •
Defensor •
Peñarol •
Cerro •
Danubio •
El Tanque Sisley •
Fénix •
Miramar Misiones •
Wanderers •
Racing •
Rentistas •
River Plate •
Juventud •
Cerro Largo •
Sud América



**[ve-venezuela/clubs.txt](ve-venezuela/clubs.txt)** _(18)_ -- 
Caracas •
Dvo. La Guaira •
Dvo. Petare •
Dvo. Táchira •
Zamora •
Dvo. Lara •
Dvo. Anzoátegui •
Mineros •
Atlético El Vigía •
Llaneros •
Atlético Venezuela •
Zulia •
Aragua •
Estudiantes •
Tucanes •
Yaracuyanos •
Carabobo •
Trujillanos





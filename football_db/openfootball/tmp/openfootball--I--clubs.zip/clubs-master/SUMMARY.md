

### Clubs


**[africa/eg-egypt/clubs.txt](africa/eg-egypt/clubs.txt)** _(18)_ -- 
Al Ahly •
Zamalek •
Ismaily •
Al Ittihad Al Sakandary •
Al Mokawloon Al Arab •
El Dakhleya •
El Entag El Harby •
El Gouna •
Enppi •
Ghazl El Mahalla •
Haras El Hodood •
Ittihad El Shorta •
Misr El Makasa •
Petrojet •
Smouha •
Tala'ea El Gaish •
Telephonat Bani Sweif •
Wadi Degla



**[africa/ma-morocco/clubs.txt](africa/ma-morocco/clubs.txt)** _(1)_ -- 
Raja Casablanca



**[asia/clubs.txt](asia/clubs.txt)** _(9)_ -- 
Astana _(kz)_ •
FC Aktobe _(kz)_ •
Shakhter _(kz)_ •
FC Tobol Kostanay _(kz)_ •
FC Irtysh Pavlodar _(kz)_ •
FC Ordabasy Shymkent _(kz)_ •
FC Atyrau _(kz)_ •
FC Zhetysu Taldykorgan _(kz)_ •
FC Okzhetpes Kokshetau _(kz)_



**[asia/cn-china/clubs.txt](asia/cn-china/clubs.txt)** _(1)_ -- 
Guangzhou Evergrande



**[asia/jp-japan/clubs.txt](asia/jp-japan/clubs.txt)** _(18)_ -- 
Albirex Niigata •
Kashima Antlers •
Omiya Ardija •
Cerezo Osaka •
Yokohama F. Marinos •
Kawasaki Frontale •
Nagoya Grampus •
Júbilo Iwata •
Oita Trinita •
Urawa Red Diamonds •
Kashiwa Reysol •
Shimizu S-Pulse •
Sagan Tosu •
Sanfrecce Hiroshima •
Shonan Bellmare •
FC Tokyo •
Vegalta Sendai •
Ventforet Kofu



**[asia/kr-south-korea/clubs.txt](asia/kr-south-korea/clubs.txt)** _(14)_ -- 
Busan I'Park •
Chunnam Dragons •
Daegu FC •
Daejeon Citizen •
Gangwon FC •
Gyeongnam FC •
Incheon United •
Jeju United •
Jeonbuk Motors •
Pohang Steelers •
Seongnam Ilhwa Chunma •
FC Seoul •
Suwon Bluewings •
Ulsan Hyundai



**[caribbean/clubs.txt](caribbean/clubs.txt)** _(5)_ -- 
Caledonia _(tt)_ •
W Connection _(tt)_ •
Puerto Rico Islanders _(pr)_ •
Tempête _(ht)_ •
Valencia _(ht)_



**[central-america/clubs.txt](central-america/clubs.txt)** _(23)_ -- 
Metapán _(sv)_ •
Águila _(sv)_ •
CD FAS _(sv)_ •
Alianza _(sv)_ •
L.A. Firpo _(sv)_ •
Alajuelense _(cr)_ •
Herediano _(cr)_ •
Cartaginés _(cr)_ •
Olimpia _(hn)_ •
Marathón _(hn)_ •
Real España _(hn)_ •
Motagua _(hn)_ •
Victoria _(hn)_ •
Municipal _(gt)_ •
Xelajú _(gt)_ •
Comunicaciones _(gt)_ •
Heredia _(gt)_ •
Chorrillo _(pa)_ •
Tauro _(pa)_ •
Árabe Unido _(pa)_ •
San Francisco _(pa)_ •
Sporting SM _(pa)_ •
R. Estelí _(ni)_



**[europe/be-belgium/clubs.txt](europe/be-belgium/clubs.txt)** _(17)_ -- 
Anderlecht •
Club Brugge •
Cercle Brugge KSV •
Oostende •
Zulte Waregem •
Kortrijk •
Gent •
Lokeren •
Waasland-Beveren •
Westerlo •
Mechelen •
Genk •
Sint-Truiden •
Leuven •
R. Standard de Liège •
Charleroi •
Mouscron-Péruwelz



**[europe/bg-bulgaria/clubs.txt](europe/bg-bulgaria/clubs.txt)** _(12)_ -- 
Levski •
Slavia Sofia •
PFC CSKA Sofia •
PFC Lokomotiv Sofia •
Botev Plovdiv •
Lokomotiv Plovdiv •
Litex •
Cherno More •
Ludogorets •
Beroe •
Montana •
Blagoevgrad



**[europe/clubs_central.txt](europe/clubs_central.txt)** _(36)_ -- 
FC USV Eschen/Mauren _(li)_ •
KKS Lech Poznań _(pl)_ •
Wisła Kraków _(pl)_ •
Legia _(pl)_ •
WKS Śląsk Wrocław _(pl)_ •
Ruch Chorzów _(pl)_ •
Jagiellonia Białystok _(pl)_ •
KSP Polonia Warszawa _(pl)_ •
MŠK Žilina _(sk)_ •
ŠK Slovan Bratislava _(sk)_ •
FC Spartak Trnava _(sk)_ •
FK Senica _(sk)_ •
MFK Košice _(sk)_ •
Dukla Banská Bystrica _(sk)_ •
FC Nitra _(sk)_ •
MFK Petržalka _(sk)_ •
Budapest Honvéd FC _(hu)_ •
MTK Budapest _(hu)_ •
Ferencvárosi TC _(hu)_ •
Videoton FC _(hu)_ •
Debreceni VSC _(hu)_ •
Győri ETO FC _(hu)_ •
Paksi SE _(hu)_ •
Kecskeméti TE _(hu)_ •
Újpest FC _(hu)_ •
Szombathelyi Haladás _(hu)_ •
Zalaegerszegi TE _(hu)_ •
NK Olimpija Ljubljana _(si)_ •
NK IB Ljubljana _(si)_ •
Maribor _(si)_ •
ND Mura 05 _(si)_ •
FC Koper _(si)_ •
ND Gorica _(si)_ •
NK Domžale _(si)_ •
NK Rudar Velenje _(si)_ •
NK Celje _(si)_



**[europe/clubs_eastern.txt](europe/clubs_eastern.txt)** _(37)_ -- 
FC Dacia Chisinau _(md)_ •
FC Zimbru Chisinau _(md)_ •
FC Sheriff _(md)_ •
FC Iskra-Stal _(md)_ •
FC Milsami Orhei _(md)_ •
FC Olimpia Balti _(md)_ •
FC Nistru Otaci _(md)_ •
BATE Borissow _(by)_ •
FC Gomel _(by)_ •
FC Dinamo Minsk _(by)_ •
FC Partizan Minsk _(by)_ •
FC Minsk _(by)_ •
FC Dnepr Mogilev _(by)_ •
FC Shakhtyor Soligorsk _(by)_ •
FC Naftan Novopolotsk _(by)_ •
FC Torpedo Zhodino _(by)_ •
FC Zestafoni _(ge)_ •
FC Dinamo Tbilisi _(ge)_ •
FC Metalurgi Rustavi _(ge)_ •
FC Dila Gori _(ge)_ •
FC WIT Georgia _(ge)_ •
FC Gagra _(ge)_ •
FC Torpedo Kutaisi _(ge)_ •
FC Pyunik _(am)_ •
Ulisses FC _(am)_ •
FC Mika _(am)_ •
FC Gandzasar _(am)_ •
FC Banants _(am)_ •
FC Shirak _(am)_ •
FC Ararat _(am)_ •
Bakı FK _(az)_ •
İnter Bakı PİK _(az)_ •
Neftçi PFK _(az)_ •
Qarabağ FK _(az)_ •
Xäzär Länkäran FK _(az)_ •
Olimpik-Şüvälan PFK _(az)_ •
Simurq PFK _(az)_



**[europe/clubs_northern.txt](europe/clubs_northern.txt)** _(68)_ -- 
KR Reykjavík _(is)_ •
Fram Reykjavík _(is)_ •
Valur Reykjavík _(is)_ •
FH Hafnarfjördur _(is)_ •
Breidablik _(is)_ •
Thór Akureyri _(is)_ •
ÍBV Vestmannaeyjar _(is)_ •
Fylkir _(is)_ •
Keflavík _(is)_ •
ÍA Akranes _(is)_ •
HB Tórshavn _(fo)_ •
B36 Tórshavn _(fo)_ •
EB/Streymur _(fo)_ •
NSÍ Runavík _(fo)_ •
Víkingur _(fo)_ •
ÍF Fuglafjørdur _(fo)_ •
Rosenborg BK _(no)_ •
Molde FK _(no)_ •
Tromsø IL _(no)_ •
Aalesunds FK _(no)_ •
Stabæk Fotball _(no)_ •
Vålerenga Fotball _(no)_ •
SK Brann _(no)_ •
Strømsgodset IF _(no)_ •
Fredrikstad FK _(no)_ •
Lillestrøm SK _(no)_ •
Viking FK _(no)_ •
Helsingborgs IF _(se)_ •
IF Elfsborg _(se)_ •
Kalmar FF _(se)_ •
AIK _(se)_ •
Malmö FF _(se)_ •
IFK Göteborg _(se)_ •
BK Häcken _(se)_ •
Örebro SK _(se)_ •
Gefle IF _(se)_ •
Djurgårdens IF _(se)_ •
HJK Helsinki _(fi)_ •
FC Inter Turku _(fi)_ •
TPS Turku _(fi)_ •
FC Honka Espoo _(fi)_ •
KuPS Kuopio _(fi)_ •
Myllykosken Pallo-47 _(fi)_ •
FC Lahti _(fi)_ •
JJK Jyväskylä _(fi)_ •
Valkeakosken Haka _(fi)_ •
Tampere United _(fi)_ •
FK Ventspils _(lv)_ •
SK Liepājas Metalurgs _(lv)_ •
Skonto FC _(lv)_ •
FC Daugava Daugavpils _(lv)_ •
FK Jelgava _(lv)_ •
FC Dinaburg _(lv)_ •
JFK Olimps/RFS _(lv)_ •
FK Ekranas _(lt)_ •
FK Sūduva _(lt)_ •
FK Tauras _(lt)_ •
FK Vėtra _(lt)_ •
FC Šiauliai _(lt)_ •
VMFD Žalgiris _(lt)_ •
FBK Kaunas _(lt)_ •
FK Banga _(lt)_ •
FC Levadia Tallinn _(ee)_ •
FC Flora Tallinn _(ee)_ •
FC TVMK Tallinn _(ee)_ •
JK Trans Narva _(ee)_ •
JK Nõmme Kalju _(ee)_ •
JK Sillamäe Kalev _(ee)_



**[europe/clubs_southern.txt](europe/clubs_southern.txt)** _(91)_ -- 
Valletta FC _(mt)_ •
Birkirkara FC _(mt)_ •
Floriana FC _(mt)_ •
Hibernians FC _(mt)_ •
Sliema Wanderers FC _(mt)_ •
Marsaxlokk FC _(mt)_ •
SP Tre Fiori _(sm)_ •
SP Tre Penne _(sm)_ •
AC Juvenes-Dogana _(sm)_ •
SP La Fiorita _(sm)_ •
AC Libertas _(sm)_ •
SC Faetano _(sm)_ •
SS Murata _(sm)_ •
Lincoln FC _(gi)_ •
Manchester 62 FC _(gi)_ •
Lynx FC _(gi)_ •
College Europa FC _(gi)_ •
Glacis United FC _(gi)_ •
Lions Gibraltar FC _(gi)_ •
St Joseph's FRAC _(gi)_ •
Gibraltar Phoenix FC _(gi)_ •
UE Sant Julià _(ad)_ •
FC Santa Coloma _(ad)_ •
UE Santa Coloma _(ad)_ •
FC Lusitans _(ad)_ •
Dinamo Zagreb _(hr)_ •
HNK Hajduk Split _(hr)_ •
RNK Split _(hr)_ •
NK Slaven Koprivnica _(hr)_ •
NK Varaždin _(hr)_ •
HNK Rijeka _(hr)_ •
NK Osijek _(hr)_ •
HNK Cibalia _(hr)_ •
HNK Šibenik _(hr)_ •
FK Partizan _(rs)_ •
FK Crvena zvezda _(rs)_ •
FK Vojvodina _(rs)_ •
OFK Beograd _(rs)_ •
FK Spartak Zlatibor voda _(rs)_ •
FK Sloboda Užice _(rs)_ •
FK Rad _(rs)_ •
FK Jagodina _(rs)_ •
FK Borac Čačak _(rs)_ •
FK Sarajevo _(ba)_ •
FK Slavija Sarajevo _(ba)_ •
FK Željezničar _(ba)_ •
HŠK Zrinjski _(ba)_ •
NK Široki Brijeg _(ba)_ •
FK Borac Banja Luka _(ba)_ •
FK Modriča _(ba)_ •
FK Metalurg Skopje _(mk)_ •
FK Makedonija Skopje _(mk)_ •
FK Rabotnički _(mk)_ •
FK Renova _(mk)_ •
FK Shkëndija 79 _(mk)_ •
FK Vardar _(mk)_ •
FK Teteks _(mk)_ •
FK Milano _(mk)_ •
FK Pelister _(mk)_ •
FK Budućnost Podgorica _(me)_ •
FK Mogren _(me)_ •
FK Zeta _(me)_ •
FK Rudar Pljevlja _(me)_ •
OFK Petrovac _(me)_ •
FK Čelik Nikšić _(me)_ •
FK Sutjeska _(me)_ •
KF Tirana _(al)_ •
FK Dinamo Tirana _(al)_ •
KS Skënderbeu _(al)_ •
KS Flamurtari _(al)_ •
KF Vllaznia _(al)_ •
KS Besa _(al)_ •
KS Teuta _(al)_ •
KF Laçi _(al)_ •
FK Partizani _(al)_ •
Olympiakos Piräus _(gr)_ •
Panathinaikos FC _(gr)_ •
PAOK FC _(gr)_ •
AEK Athens FC _(gr)_ •
Aris Thessaloniki FC _(gr)_ •
Atromitos FC _(gr)_ •
Asteras Tripolis FC _(gr)_ •
Olympiacos Volou FC _(gr)_ •
Larissa FC _(gr)_ •
APOEL _(cy)_ •
Anorthosis Famagusta FC _(cy)_ •
AC Omonia _(cy)_ •
AEK Larnaca FC _(cy)_ •
AEL Limassol FC _(cy)_ •
Apollon Limassol FC _(cy)_ •
APOP/Kinyras Peyias FC _(cy)_



**[europe/clubs_western.txt](europe/clubs_western.txt)** _(41)_ -- 
F91 Dudelange _(lu)_ •
FC Differdange 03 _(lu)_ •
AS Jeunesse Esch _(lu)_ •
CS Grevenmacher _(lu)_ •
UN Käerjéng 97 _(lu)_ •
CS Fola Esch _(lu)_ •
Racing FC Union Lëtzebuerg _(lu)_ •
Saint Patrick's Athletic FC _(ie)_ •
Shamrock Rovers FC _(ie)_ •
Bohemian FC _(ie)_ •
Sligo Rovers FC _(ie)_ •
Derry City FC _(ie)_ •
Sporting Fingal FC _(ie)_ •
Dundalk FC _(ie)_ •
Cork City FC _(ie)_ •
Drogheda United FC _(ie)_ •
Celtic _(sco)_ •
Motherwell _(sco)_ •
Dundee United _(sco)_ •
Aberdeen _(sco)_ •
St Johnstone _(sco)_ •
Inverness CT _(sco)_ •
Dundee _(sco)_ •
Kilmarnock _(sco)_ •
Partick Thistle _(sco)_ •
Ross County _(sco)_ •
St Mirren _(sco)_ •
Hamilton Accies _(sco)_ •
Linfield FC _(nir)_ •
Glentoran FC _(nir)_ •
Cliftonville FC _(nir)_ •
Crusaders FC _(nir)_ •
Portadown FC _(nir)_ •
Lisburn Distillery FC _(nir)_ •
The New Saints FC _(wal)_ •
Bangor City FC _(wal)_ •
Llanelli AFC _(wal)_ •
Rhyl FC _(wal)_ •
Cefn Druids AFC _(wal)_ •
Neath FC _(wal)_ •
Port Talbot Town FC _(wal)_



**[europe/cz-czech-republic/clubs.txt](europe/cz-czech-republic/clubs.txt)** _(16)_ -- 
Sparta Praha •
Slavia Praha •
Dukla •
Bohemians 1905 •
Mladá Boleslav •
Příbram •
Plzeň •
Liberec •
Jablonec •
Baník •
Sigma •
Teplice •
Slovácko •
Zlín •
Jihlava •
Brno



**[europe/dk-denmark/clubs.txt](europe/dk-denmark/clubs.txt)** _(13)_ -- 
København •
FC Nordsjælland •
Brøndby •
Aalborg BK •
Hobro •
Midtjylland •
AGF Aarhus •
Viborg •
Randers •
SønderjyskE •
Odense BK •
Esbjerg •
AC Horsens



**[europe/nl-netherlands/clubs.txt](europe/nl-netherlands/clubs.txt)** _(21)_ -- 
Ajax •
AZ Alkmaar •
ADO Den Haag •
Feyenoord •
Excelsior •
Heracles Almelo •
FC Twente •
Zwolle •
FC Groningen •
FC Utrecht •
NAC Breda •
NEC Nijmegen •
Vitesse •
De Graafschap •
PSV Eindhoven •
RKC Waalwijk •
Willem II •
Roda JC •
VVV-Venlo •
SC Heerenveen •
Cambuur



**[europe/pt-portugal/clubs.txt](europe/pt-portugal/clubs.txt)** _(10)_ -- 
Porto •
Braga •
Benfica •
Sporting Lisboa •
CS Marítimo •
CD Nacional •
A. Académica de Coimbra •
FC Paços de Ferreira •
Vitória SC •
Vitória FC



**[europe/ro-romania/clubs.txt](europe/ro-romania/clubs.txt)** _(18)_ -- 
Dinamo București •
Rapid București •
Steaua •
CFR Cluj •
U Cluj •
Astra Giurgiu •
Ceahlaul Piatra Neamt •
Concordia Chiajna •
CSMS Iasi •
FC Brasov •
FC Severin •
FC Vaslui •
Gaz Metan Medias •
Gloria Bistrita •
Otelul Galati •
Pandurii Tg Jiu •
Petrolul Ploiesti •
Viitorul Constanta



**[europe/ru-russia/clubs.txt](europe/ru-russia/clubs.txt)** _(35)_ -- 
Lokomotiv •
CSKA Moskva •
Dynamo •
Spartak •
Moskva •
Torpedo •
Zenit •
Rubin Kazan •
FC Amkar Perm •
Anzhi Makhachkala •
FC Sibir Novosibirsk •
FC Alania Vladikavkaz •
PFC Krylya Sovetov Samara •
Arsenal •
Chernomorets •
Khimki •
Krasnodar •
Kuban •
Luch •
Mordovia •
Spartak Nalchik •
Nizhnii Novgorod •
Rostov •
Rotor •
Saturn •
Shinnik •
SKA-Energiia •
Sokol •
Terek •
Tom •
Tosno •
Ufa •
Ural •
Uralan •
Volga



**[europe/sco-scotland/clubs.txt](europe/sco-scotland/clubs.txt)** _(12)_ -- 
Celtic •
Motherwell •
Dundee United •
Aberdeen •
St Johnstone •
Inverness CT •
Dundee •
Kilmarnock •
Partick Thistle •
Ross County •
St Mirren •
Hamilton Accies



**[europe/tr-turkey/clubs.txt](europe/tr-turkey/clubs.txt)** _(9)_ -- 
Galatasaray •
Fenerbahçe •
Beşiktaş JK •
Trabzonspor AŞ •
Bursaspor •
Sivasspor •
Eskişehirspor •
Gaziantepspor •
Kayserispor



**[europe/ua-ukraine/clubs.txt](europe/ua-ukraine/clubs.txt)** _(9)_ -- 
Dynamo Kiew •
Shakhtar Donetsk •
FC Metalurh Donetsk •
FC Metalist Kharkiv •
FC Dnipro •
FC Vorskla Poltava •
FC Karpaty Lviv •
SC Tavriya Simferopol •
FC Arsenal Kyiv



**[middle-east/clubs.txt](middle-east/clubs.txt)** _(7)_ -- 
Hapoel Tel-Aviv FC _(il)_ •
Bnei Yehuda Tel-Aviv FC _(il)_ •
Maccabi Tel-Aviv FC _(il)_ •
Maccabi Haifa FC _(il)_ •
Hapoel Kiryat Shmona FC _(il)_ •
Maccabi Netanya FC _(il)_ •
Beitar Jerusalem FC _(il)_



**[pacific/au-australia/clubs.txt](pacific/au-australia/clubs.txt)** _(9)_ -- 
Adelaide United •
Brisbane Roar •
Central Coast Mariners •
Melbourne Heart •
Melbourne Victory •
Newcastle Jets •
Perth Glory •
Sydney FC •
Western Sydney Wanderers



**[pacific/nz-new-zealand/clubs.txt](pacific/nz-new-zealand/clubs.txt)** _(9)_ -- 
Auckland City •
Canterbury United •
Hawke's Bay United •
Otago United •
Team Wellington •
Waikato FC •
Waitakere United •
YoungHeart Manawatu •
Wellington Phoenix



**[south-america/ar-argentina/clubs.txt](south-america/ar-argentina/clubs.txt)** _(20)_ -- 
All Boys •
Argentions •
Boca •
River •
San Lorenzo •
Vélez •
Tigre •
Independiente •
Racing •
Quilmes •
Lanús •
Arsenal •
Estudiantes •
Colón •
Unión •
Newell's •
At. de Rafaela •
Belgrano •
Godoy Cruz •
San Martín



**[south-america/bo-bolivia/clubs.txt](south-america/bo-bolivia/clubs.txt)** _(5)_ -- 
Bolívar _(bo)_ •
Strongest _(bo)_ •
Real Potosí _(bo)_ •
San José _(bo)_ •
Oriente Petrolero _(bo)_



**[south-america/cl-chile/clubs.txt](south-america/cl-chile/clubs.txt)** _(5)_ -- 
Universidad de Chile _(cl)_ •
Universidad Católica _(cl)_ •
Unión Española _(cl)_ •
Huachipato _(cl)_ •
Iquique _(cl)_



**[south-america/clubs.txt](south-america/clubs.txt)** _(1)_ -- 
Alpha United _(gy)_



**[south-america/co-colombia/clubs.txt](south-america/co-colombia/clubs.txt)** _(6)_ -- 
Millonarios Bogotá •
Santa Fe •
At. Nacional •
Junior •
Once Caldas •
Deportes Tolima



**[south-america/ec-ecuador/clubs.txt](south-america/ec-ecuador/clubs.txt)** _(6)_ -- 
Deportivo Quito _(ec)_ •
El Nacional _(ec)_ •
LDU Quito _(ec)_ •
CS Emelec _(ec)_ •
Barcelona _(ec)_ •
LDU Loja _(ec)_



**[south-america/pe-peru/clubs.txt](south-america/pe-peru/clubs.txt)** _(6)_ -- 
Alianza Lima _(pe)_ •
Sporting Cristal _(pe)_ •
Juan Aurich _(pe)_ •
Sport Huancayo _(pe)_ •
Real Garcilaso _(pe)_ •
Universidad César Vallejo _(pe)_



**[south-america/py-paraguay/clubs.txt](south-america/py-paraguay/clubs.txt)** _(4)_ -- 
Club Libertad Asunción _(py)_ •
Olimpia _(py)_ •
Nacional _(py)_ •
Cerro Porteño _(py)_



**[south-america/uy-uruguay/clubs.txt](south-america/uy-uruguay/clubs.txt)** _(16)_ -- 
Liverpool •
Nacional •
Defensor •
Peñarol •
Cerro •
Danubio •
El Tanque Sisley •
Fénix •
Miramar Misiones •
Wanderers •
Racing •
Rentistas •
River Plate •
Juventud •
Cerro Largo •
Sud América



**[south-america/ve-venezuela/clubs.txt](south-america/ve-venezuela/clubs.txt)** _(18)_ -- 
Caracas •
Dvo. La Guaira •
Dvo. Petare •
Dvo. Táchira •
Zamora •
Dvo. Lara •
Dvo. Anzoátegui •
Mineros •
Atlético El Vigía •
Llaneros •
Atlético Venezuela •
Zulia •
Aragua •
Estudiantes •
Tucanes •
Yaracuyanos •
Carabobo •
Trujillanos





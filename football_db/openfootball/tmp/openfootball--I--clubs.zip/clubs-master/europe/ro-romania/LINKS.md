
## Links

### Romania Liga1

Official  -> [`liga1.ro`](http://liga1.ro)

- 18 Teams (4↓↑)
- (1 CL, 2 EL)  CL/2.QR, 2 EL/2.QR, EL/1.QR -- UEFA Ranking #22


#### Wikipedia

- [Liga_I](http://en.wikipedia.org/wiki/Liga_I)



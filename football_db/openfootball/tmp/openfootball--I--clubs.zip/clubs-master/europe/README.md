

### Clubs


**[be-belgium/clubs.txt](be-belgium/clubs.txt)** _(17)_ -- 
Anderlecht •
Club Brugge •
Cercle Brugge KSV •
Oostende •
Zulte Waregem •
Kortrijk •
Gent •
Lokeren •
Waasland-Beveren •
Westerlo •
Mechelen •
Genk •
Sint-Truiden •
Leuven •
R. Standard de Liège •
Charleroi •
Mouscron-Péruwelz



**[bg-bulgaria/clubs.txt](bg-bulgaria/clubs.txt)** _(12)_ -- 
Levski •
Slavia Sofia •
PFC CSKA Sofia •
PFC Lokomotiv Sofia •
Botev Plovdiv •
Lokomotiv Plovdiv •
Litex •
Cherno More •
Ludogorets •
Beroe •
Montana •
Blagoevgrad



**[clubs_central.txt](clubs_central.txt)** _(36)_ -- 
FC USV Eschen/Mauren _(li)_ •
KKS Lech Poznań _(pl)_ •
Wisła Kraków _(pl)_ •
Legia _(pl)_ •
WKS Śląsk Wrocław _(pl)_ •
Ruch Chorzów _(pl)_ •
Jagiellonia Białystok _(pl)_ •
KSP Polonia Warszawa _(pl)_ •
MŠK Žilina _(sk)_ •
ŠK Slovan Bratislava _(sk)_ •
FC Spartak Trnava _(sk)_ •
FK Senica _(sk)_ •
MFK Košice _(sk)_ •
Dukla Banská Bystrica _(sk)_ •
FC Nitra _(sk)_ •
MFK Petržalka _(sk)_ •
Budapest Honvéd FC _(hu)_ •
MTK Budapest _(hu)_ •
Ferencvárosi TC _(hu)_ •
Videoton FC _(hu)_ •
Debreceni VSC _(hu)_ •
Győri ETO FC _(hu)_ •
Paksi SE _(hu)_ •
Kecskeméti TE _(hu)_ •
Újpest FC _(hu)_ •
Szombathelyi Haladás _(hu)_ •
Zalaegerszegi TE _(hu)_ •
NK Olimpija Ljubljana _(si)_ •
NK IB Ljubljana _(si)_ •
Maribor _(si)_ •
ND Mura 05 _(si)_ •
FC Koper _(si)_ •
ND Gorica _(si)_ •
NK Domžale _(si)_ •
NK Rudar Velenje _(si)_ •
NK Celje _(si)_



**[clubs_eastern.txt](clubs_eastern.txt)** _(37)_ -- 
FC Dacia Chisinau _(md)_ •
FC Zimbru Chisinau _(md)_ •
FC Sheriff _(md)_ •
FC Iskra-Stal _(md)_ •
FC Milsami Orhei _(md)_ •
FC Olimpia Balti _(md)_ •
FC Nistru Otaci _(md)_ •
BATE Borissow _(by)_ •
FC Gomel _(by)_ •
FC Dinamo Minsk _(by)_ •
FC Partizan Minsk _(by)_ •
FC Minsk _(by)_ •
FC Dnepr Mogilev _(by)_ •
FC Shakhtyor Soligorsk _(by)_ •
FC Naftan Novopolotsk _(by)_ •
FC Torpedo Zhodino _(by)_ •
FC Zestafoni _(ge)_ •
FC Dinamo Tbilisi _(ge)_ •
FC Metalurgi Rustavi _(ge)_ •
FC Dila Gori _(ge)_ •
FC WIT Georgia _(ge)_ •
FC Gagra _(ge)_ •
FC Torpedo Kutaisi _(ge)_ •
FC Pyunik _(am)_ •
Ulisses FC _(am)_ •
FC Mika _(am)_ •
FC Gandzasar _(am)_ •
FC Banants _(am)_ •
FC Shirak _(am)_ •
FC Ararat _(am)_ •
Bakı FK _(az)_ •
İnter Bakı PİK _(az)_ •
Neftçi PFK _(az)_ •
Qarabağ FK _(az)_ •
Xäzär Länkäran FK _(az)_ •
Olimpik-Şüvälan PFK _(az)_ •
Simurq PFK _(az)_



**[clubs_northern.txt](clubs_northern.txt)** _(68)_ -- 
KR Reykjavík _(is)_ •
Fram Reykjavík _(is)_ •
Valur Reykjavík _(is)_ •
FH Hafnarfjördur _(is)_ •
Breidablik _(is)_ •
Thór Akureyri _(is)_ •
ÍBV Vestmannaeyjar _(is)_ •
Fylkir _(is)_ •
Keflavík _(is)_ •
ÍA Akranes _(is)_ •
HB Tórshavn _(fo)_ •
B36 Tórshavn _(fo)_ •
EB/Streymur _(fo)_ •
NSÍ Runavík _(fo)_ •
Víkingur _(fo)_ •
ÍF Fuglafjørdur _(fo)_ •
Rosenborg BK _(no)_ •
Molde FK _(no)_ •
Tromsø IL _(no)_ •
Aalesunds FK _(no)_ •
Stabæk Fotball _(no)_ •
Vålerenga Fotball _(no)_ •
SK Brann _(no)_ •
Strømsgodset IF _(no)_ •
Fredrikstad FK _(no)_ •
Lillestrøm SK _(no)_ •
Viking FK _(no)_ •
Helsingborgs IF _(se)_ •
IF Elfsborg _(se)_ •
Kalmar FF _(se)_ •
AIK _(se)_ •
Malmö FF _(se)_ •
IFK Göteborg _(se)_ •
BK Häcken _(se)_ •
Örebro SK _(se)_ •
Gefle IF _(se)_ •
Djurgårdens IF _(se)_ •
HJK Helsinki _(fi)_ •
FC Inter Turku _(fi)_ •
TPS Turku _(fi)_ •
FC Honka Espoo _(fi)_ •
KuPS Kuopio _(fi)_ •
Myllykosken Pallo-47 _(fi)_ •
FC Lahti _(fi)_ •
JJK Jyväskylä _(fi)_ •
Valkeakosken Haka _(fi)_ •
Tampere United _(fi)_ •
FK Ventspils _(lv)_ •
SK Liepājas Metalurgs _(lv)_ •
Skonto FC _(lv)_ •
FC Daugava Daugavpils _(lv)_ •
FK Jelgava _(lv)_ •
FC Dinaburg _(lv)_ •
JFK Olimps/RFS _(lv)_ •
FK Ekranas _(lt)_ •
FK Sūduva _(lt)_ •
FK Tauras _(lt)_ •
FK Vėtra _(lt)_ •
FC Šiauliai _(lt)_ •
VMFD Žalgiris _(lt)_ •
FBK Kaunas _(lt)_ •
FK Banga _(lt)_ •
FC Levadia Tallinn _(ee)_ •
FC Flora Tallinn _(ee)_ •
FC TVMK Tallinn _(ee)_ •
JK Trans Narva _(ee)_ •
JK Nõmme Kalju _(ee)_ •
JK Sillamäe Kalev _(ee)_



**[clubs_southern.txt](clubs_southern.txt)** _(91)_ -- 
Valletta FC _(mt)_ •
Birkirkara FC _(mt)_ •
Floriana FC _(mt)_ •
Hibernians FC _(mt)_ •
Sliema Wanderers FC _(mt)_ •
Marsaxlokk FC _(mt)_ •
SP Tre Fiori _(sm)_ •
SP Tre Penne _(sm)_ •
AC Juvenes-Dogana _(sm)_ •
SP La Fiorita _(sm)_ •
AC Libertas _(sm)_ •
SC Faetano _(sm)_ •
SS Murata _(sm)_ •
Lincoln FC _(gi)_ •
Manchester 62 FC _(gi)_ •
Lynx FC _(gi)_ •
College Europa FC _(gi)_ •
Glacis United FC _(gi)_ •
Lions Gibraltar FC _(gi)_ •
St Joseph's FRAC _(gi)_ •
Gibraltar Phoenix FC _(gi)_ •
UE Sant Julià _(ad)_ •
FC Santa Coloma _(ad)_ •
UE Santa Coloma _(ad)_ •
FC Lusitans _(ad)_ •
Dinamo Zagreb _(hr)_ •
HNK Hajduk Split _(hr)_ •
RNK Split _(hr)_ •
NK Slaven Koprivnica _(hr)_ •
NK Varaždin _(hr)_ •
HNK Rijeka _(hr)_ •
NK Osijek _(hr)_ •
HNK Cibalia _(hr)_ •
HNK Šibenik _(hr)_ •
FK Partizan _(rs)_ •
FK Crvena zvezda _(rs)_ •
FK Vojvodina _(rs)_ •
OFK Beograd _(rs)_ •
FK Spartak Zlatibor voda _(rs)_ •
FK Sloboda Užice _(rs)_ •
FK Rad _(rs)_ •
FK Jagodina _(rs)_ •
FK Borac Čačak _(rs)_ •
FK Sarajevo _(ba)_ •
FK Slavija Sarajevo _(ba)_ •
FK Željezničar _(ba)_ •
HŠK Zrinjski _(ba)_ •
NK Široki Brijeg _(ba)_ •
FK Borac Banja Luka _(ba)_ •
FK Modriča _(ba)_ •
FK Metalurg Skopje _(mk)_ •
FK Makedonija Skopje _(mk)_ •
FK Rabotnički _(mk)_ •
FK Renova _(mk)_ •
FK Shkëndija 79 _(mk)_ •
FK Vardar _(mk)_ •
FK Teteks _(mk)_ •
FK Milano _(mk)_ •
FK Pelister _(mk)_ •
FK Budućnost Podgorica _(me)_ •
FK Mogren _(me)_ •
FK Zeta _(me)_ •
FK Rudar Pljevlja _(me)_ •
OFK Petrovac _(me)_ •
FK Čelik Nikšić _(me)_ •
FK Sutjeska _(me)_ •
KF Tirana _(al)_ •
FK Dinamo Tirana _(al)_ •
KS Skënderbeu _(al)_ •
KS Flamurtari _(al)_ •
KF Vllaznia _(al)_ •
KS Besa _(al)_ •
KS Teuta _(al)_ •
KF Laçi _(al)_ •
FK Partizani _(al)_ •
Olympiakos Piräus _(gr)_ •
Panathinaikos FC _(gr)_ •
PAOK FC _(gr)_ •
AEK Athens FC _(gr)_ •
Aris Thessaloniki FC _(gr)_ •
Atromitos FC _(gr)_ •
Asteras Tripolis FC _(gr)_ •
Olympiacos Volou FC _(gr)_ •
Larissa FC _(gr)_ •
APOEL _(cy)_ •
Anorthosis Famagusta FC _(cy)_ •
AC Omonia _(cy)_ •
AEK Larnaca FC _(cy)_ •
AEL Limassol FC _(cy)_ •
Apollon Limassol FC _(cy)_ •
APOP/Kinyras Peyias FC _(cy)_



**[clubs_western.txt](clubs_western.txt)** _(41)_ -- 
F91 Dudelange _(lu)_ •
FC Differdange 03 _(lu)_ •
AS Jeunesse Esch _(lu)_ •
CS Grevenmacher _(lu)_ •
UN Käerjéng 97 _(lu)_ •
CS Fola Esch _(lu)_ •
Racing FC Union Lëtzebuerg _(lu)_ •
Saint Patrick's Athletic FC _(ie)_ •
Shamrock Rovers FC _(ie)_ •
Bohemian FC _(ie)_ •
Sligo Rovers FC _(ie)_ •
Derry City FC _(ie)_ •
Sporting Fingal FC _(ie)_ •
Dundalk FC _(ie)_ •
Cork City FC _(ie)_ •
Drogheda United FC _(ie)_ •
Celtic _(sco)_ •
Motherwell _(sco)_ •
Dundee United _(sco)_ •
Aberdeen _(sco)_ •
St Johnstone _(sco)_ •
Inverness CT _(sco)_ •
Dundee _(sco)_ •
Kilmarnock _(sco)_ •
Partick Thistle _(sco)_ •
Ross County _(sco)_ •
St Mirren _(sco)_ •
Hamilton Accies _(sco)_ •
Linfield FC _(nir)_ •
Glentoran FC _(nir)_ •
Cliftonville FC _(nir)_ •
Crusaders FC _(nir)_ •
Portadown FC _(nir)_ •
Lisburn Distillery FC _(nir)_ •
The New Saints FC _(wal)_ •
Bangor City FC _(wal)_ •
Llanelli AFC _(wal)_ •
Rhyl FC _(wal)_ •
Cefn Druids AFC _(wal)_ •
Neath FC _(wal)_ •
Port Talbot Town FC _(wal)_



**[cz-czech-republic/clubs.txt](cz-czech-republic/clubs.txt)** _(16)_ -- 
Sparta Praha •
Slavia Praha •
Dukla •
Bohemians 1905 •
Mladá Boleslav •
Příbram •
Plzeň •
Liberec •
Jablonec •
Baník •
Sigma •
Teplice •
Slovácko •
Zlín •
Jihlava •
Brno



**[dk-denmark/clubs.txt](dk-denmark/clubs.txt)** _(13)_ -- 
København •
FC Nordsjælland •
Brøndby •
Aalborg BK •
Hobro •
Midtjylland •
AGF Aarhus •
Viborg •
Randers •
SønderjyskE •
Odense BK •
Esbjerg •
AC Horsens



**[nl-netherlands/clubs.txt](nl-netherlands/clubs.txt)** _(21)_ -- 
Ajax •
AZ Alkmaar •
ADO Den Haag •
Feyenoord •
Excelsior •
Heracles Almelo •
FC Twente •
Zwolle •
FC Groningen •
FC Utrecht •
NAC Breda •
NEC Nijmegen •
Vitesse •
De Graafschap •
PSV Eindhoven •
RKC Waalwijk •
Willem II •
Roda JC •
VVV-Venlo •
SC Heerenveen •
Cambuur



**[pt-portugal/clubs.txt](pt-portugal/clubs.txt)** _(10)_ -- 
Porto •
Braga •
Benfica •
Sporting Lisboa •
CS Marítimo •
CD Nacional •
A. Académica de Coimbra •
FC Paços de Ferreira •
Vitória SC •
Vitória FC



**[ro-romania/clubs.txt](ro-romania/clubs.txt)** _(18)_ -- 
Dinamo București •
Rapid București •
Steaua •
CFR Cluj •
U Cluj •
Astra Giurgiu •
Ceahlaul Piatra Neamt •
Concordia Chiajna •
CSMS Iasi •
FC Brasov •
FC Severin •
FC Vaslui •
Gaz Metan Medias •
Gloria Bistrita •
Otelul Galati •
Pandurii Tg Jiu •
Petrolul Ploiesti •
Viitorul Constanta



**[ru-russia/clubs.txt](ru-russia/clubs.txt)** _(35)_ -- 
Lokomotiv •
CSKA Moskva •
Dynamo •
Spartak •
Moskva •
Torpedo •
Zenit •
Rubin Kazan •
FC Amkar Perm •
Anzhi Makhachkala •
FC Sibir Novosibirsk •
FC Alania Vladikavkaz •
PFC Krylya Sovetov Samara •
Arsenal •
Chernomorets •
Khimki •
Krasnodar •
Kuban •
Luch •
Mordovia •
Spartak Nalchik •
Nizhnii Novgorod •
Rostov •
Rotor •
Saturn •
Shinnik •
SKA-Energiia •
Sokol •
Terek •
Tom •
Tosno •
Ufa •
Ural •
Uralan •
Volga



**[sco-scotland/clubs.txt](sco-scotland/clubs.txt)** _(12)_ -- 
Celtic •
Motherwell •
Dundee United •
Aberdeen •
St Johnstone •
Inverness CT •
Dundee •
Kilmarnock •
Partick Thistle •
Ross County •
St Mirren •
Hamilton Accies



**[tr-turkey/clubs.txt](tr-turkey/clubs.txt)** _(9)_ -- 
Galatasaray •
Fenerbahçe •
Beşiktaş JK •
Trabzonspor AŞ •
Bursaspor •
Sivasspor •
Eskişehirspor •
Gaziantepspor •
Kayserispor



**[ua-ukraine/clubs.txt](ua-ukraine/clubs.txt)** _(9)_ -- 
Dynamo Kiew •
Shakhtar Donetsk •
FC Metalurh Donetsk •
FC Metalist Kharkiv •
FC Dnipro •
FC Vorskla Poltava •
FC Karpaty Lviv •
SC Tavriya Simferopol •
FC Arsenal Kyiv





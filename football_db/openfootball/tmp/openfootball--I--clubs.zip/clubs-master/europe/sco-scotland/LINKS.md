## Links

### Scottish Premiership

Official site -> [`spfl.co.uk`](http://spfl.co.uk)

- 12 Teams
- CL/2.QR, EL/3.QR, 2 EL/2.QR -- UEFA Ranking #18


#### Wikipedia

- [Scottish_Premiership](http://en.wikipedia.org/wiki/Scottish_Premiership)
- [2014-15_Scottish_Premiership](http://en.wikipedia.org/wiki/2014–15_Scottish_Premiership)


### Clubs


**[clubs.txt](clubs.txt)** _(23)_ -- 
Metapán _(sv)_ •
Águila _(sv)_ •
CD FAS _(sv)_ •
Alianza _(sv)_ •
L.A. Firpo _(sv)_ •
Alajuelense _(cr)_ •
Herediano _(cr)_ •
Cartaginés _(cr)_ •
Olimpia _(hn)_ •
Marathón _(hn)_ •
Real España _(hn)_ •
Motagua _(hn)_ •
Victoria _(hn)_ •
Municipal _(gt)_ •
Xelajú _(gt)_ •
Comunicaciones _(gt)_ •
Heredia _(gt)_ •
Chorrillo _(pa)_ •
Tauro _(pa)_ •
Árabe Unido _(pa)_ •
San Francisco _(pa)_ •
Sporting SM _(pa)_ •
R. Estelí _(ni)_





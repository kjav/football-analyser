

### Clubs


**[clubs.txt](clubs.txt)** _(7)_ -- 
Hapoel Tel-Aviv FC _(il)_ •
Bnei Yehuda Tel-Aviv FC _(il)_ •
Maccabi Tel-Aviv FC _(il)_ •
Maccabi Haifa FC _(il)_ •
Hapoel Kiryat Shmona FC _(il)_ •
Maccabi Netanya FC _(il)_ •
Beitar Jerusalem FC _(il)_





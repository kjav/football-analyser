
## Links

### Australia A-League

- 10 Teams


#### Wikipedia

- [2012–13_A-League](http://en.wikipedia.org/wiki/2012–13_A-League)


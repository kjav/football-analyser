

### Clubs


**[au-australia/clubs.txt](au-australia/clubs.txt)** _(9)_ -- 
Adelaide United •
Brisbane Roar •
Central Coast Mariners •
Melbourne Heart •
Melbourne Victory •
Newcastle Jets •
Perth Glory •
Sydney FC •
Western Sydney Wanderers



**[nz-new-zealand/clubs.txt](nz-new-zealand/clubs.txt)** _(9)_ -- 
Auckland City •
Canterbury United •
Hawke's Bay United •
Otago United •
Team Wellington •
Waikato FC •
Waitakere United •
YoungHeart Manawatu •
Wellington Phoenix





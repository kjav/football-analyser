

### Clubs


**[eg-egypt/clubs.txt](eg-egypt/clubs.txt)** _(18)_ -- 
Al Ahly •
Zamalek •
Ismaily •
Al Ittihad Al Sakandary •
Al Mokawloon Al Arab •
El Dakhleya •
El Entag El Harby •
El Gouna •
Enppi •
Ghazl El Mahalla •
Haras El Hodood •
Ittihad El Shorta •
Misr El Makasa •
Petrojet •
Smouha •
Tala'ea El Gaish •
Telephonat Bani Sweif •
Wadi Degla



**[ma-morocco/clubs.txt](ma-morocco/clubs.txt)** _(1)_ -- 
Raja Casablanca





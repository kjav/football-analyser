# Notes on Asia


In Asia?
========

### Middle East

NB: Middle East countries are listed in a separate folder

### Russia / Turkey / Cyprus

NB: Russia and Turkey are listed in Europe (geographicaly in Asia n Europe)

NB: Cyprus is listed in Europe (geographicaly in Asia, politically in Europe - part of European Union)


Regions
=======

### regions (United Nations geoscheme)

- Central Asia
- East Asia
- North Asia
- South Asia | Southern Asia
- Southeast Asia
- Western Asia | Middle East | Near East (NB: listed in Middle East)
  - Arabian Peninsula
  - South Caucasus  (NB: listed in Europe)
  - Fertile Crescent


### central asia

see <http://en.wikipedia.org/wiki/Central_Asia>


### east asia

see <http://en.wikipedia.org/wiki/East_Asia>

###  south asia

see <http://en.wikipedia.org/wiki/South_Asia>

- add afghanistan here - why? why not?

### southeast asia

see <http://en.wikipedia.org/wiki/Southeast_Asia>


# Notes on South America


Regions
=======

sub regions:

- southern cone - see <http://en.wikipedia.org/wiki/Southern_Cone>
- andean states - see <http://en.wikipedia.org/wiki/Andean_states>

### Andean States

- Add Venezuela to Andean States too - why? why not?


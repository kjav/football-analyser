# Notes on Africa

Regions
=======

see <http://en.wikipedia.org/wiki/Africa#Territories_and_regions>

- Northern Africa
- Western Africa
- Central Africa
- Eastern Africa
- Southern Africa


# Notes on Middle East (Western Asia)


In Middle East?
===============

### Egypt, Cyprus, Turkey

- NB: egypt listed in africa - marked as middle_east  -- western_asia too?
- NB: cyprus listed in europe - mark as middle_east|western_asia 
- NB: turkey listed in europe - mark as middle_east|western_asia  ??

### South Caucasus

NB: Georgia, Armenia n Azerbaijan Listed in Europe


Regions
=======

see <http://en.wikipedia.org/wiki/Middle_East>

subregions used:

- arabian peninsula
- south caucasus  (NB: listed in Europe)
- fertile crescent



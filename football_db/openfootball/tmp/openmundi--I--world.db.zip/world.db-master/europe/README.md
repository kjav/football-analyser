# Europe

# Notes on Slovakia (sk)



### Wikipedia

- [NUTS_of_Slovakia](http://en.wikipedia.org/wiki/NUTS_of_Slovakia) - Regions
- [ISO_3166-2:SK](http://en.wikipedia.org/wiki/ISO_3166-2:SK)
- [Regions_of_Slovakia](http://en.wikipedia.org/wiki/Regions_of_Slovakia)
- [Template:Largest_cities_of_Slovakia](http://en.wikipedia.org/wiki/Template:Largest_cities_of_Slovakia)

## Sources

- [Statoids Slovakia](http://www.statoids.com/usk.html)


## Regions

- Use ISO 3166-2 for two-letter codes

## Keys / Codes

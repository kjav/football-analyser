# Stats

```
3 leagues
Primera División (es) |  4 events
Segunda División (es.2) |  0 events
Copa del Rey (es.cup) |  0 events
42 teams
4 events:
#######################
## 2015/16 Primera División  |  20 Teams, 380 Matches, 310 Goals (+0 a.e.t.)
    0 Groups, 38 Rounds (38 Matchdays, 0 K.O.s)
1 (10)  2 (10)  3 (10)  4 (10)  5 (10)  6 (10)  7 (10)  8 (10)  9 (10)  10 (10)  11 (10)  12 (10)  13 (10)  14 (10)  15 (10)  16 (10)  17 (10)  18 (10)  19 (10)  20 (10)  21 (10)  22 (10)  23 (10)  24 (10)  25 (10)  26 (10)  27 (10)  28 (10)  29 (10)  30 (10)  31 (10)  32 (10)  33 (10)  34 (10)  35 (10)  36 (10)  37 (10)  38 (10)  

#######################
## 2014/15 Primera División  |  20 Teams, 378 Matches, 1005 Goals (+0 a.e.t.)
    0 Groups, 38 Rounds (38 Matchdays, 0 K.O.s)
1 (10)  2 (10)  3 (10)  4 (10)  5 (10)  6 (10)  7 (10)  8 (10)  9 (10)  10 (10)  11 (10)  12 (10)  13 (10)  14 (10)  15 (10)  16 (10)  17 (10)  18 (10)  19 (10)  20 (10)  21 (10)  22 (9)  23 (10)  24 (10)  25 (9)  26 (10)  27 (10)  28 (10)  29 (10)  30 (10)  31 (10)  32 (10)  33 (10)  34 (10)  35 (10)  36 (10)  37 (10)  38 (10)  

#######################
## 2013/14 Primera División  |  20 Teams, 380 Matches, 1045 Goals (+0 a.e.t.)
    0 Groups, 38 Rounds (38 Matchdays, 0 K.O.s)
1 (10)  2 (10)  3 (10)  4 (10)  5 (10)  6 (10)  7 (10)  8 (10)  9 (10)  10 (10)  11 (10)  12 (10)  13 (10)  14 (10)  15 (10)  16 (10)  17 (10)  18 (10)  19 (10)  20 (10)  21 (10)  22 (10)  23 (10)  24 (10)  25 (10)  26 (10)  27 (10)  28 (10)  29 (10)  30 (10)  31 (10)  32 (10)  33 (10)  34 (10)  35 (10)  36 (10)  37 (10)  38 (10)  

#######################
## 2012/13 Primera División  |  20 Teams, 380 Matches, 1091 Goals (+0 a.e.t.)
    0 Groups, 38 Rounds (38 Matchdays, 0 K.O.s)
1 (10)  2 (10)  3 (10)  4 (10)  5 (10)  6 (10)  7 (10)  8 (10)  9 (10)  10 (10)  11 (10)  12 (10)  13 (10)  14 (10)  15 (10)  16 (10)  17 (10)  18 (10)  19 (10)  20 (10)  21 (10)  22 (10)  23 (10)  24 (10)  25 (10)  26 (10)  27 (10)  28 (10)  29 (10)  30 (10)  31 (10)  32 (10)  33 (10)  34 (10)  35 (10)  36 (10)  37 (10)  38 (10)  

79 logs:
[warn] Rakefile - 2015-11-28 19:08:47 +0100
[warn] hash reader - found implicit bool (no) for key; adding quotes to turn into string; see yaml.org/refcard.html (path=)
[warn] no country match found for >Bonaire<; skipping line; in [1-codes/fifa]
[warn] no country match found for >Kosovo<; skipping line; in [1-codes/fifa]
[warn] no country match found for >Zanzibar<; skipping line; in [1-codes/fifa]
[warn] no country match found for >Saint-Martin<; skipping line; in [1-codes/fifa]
[warn] no country match found for >Ashmore and Cartier Islands (AU)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Akrotiri (UK)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Burma<; skipping line; in [1-codes/fips]
[warn] no country match found for >Navassa Island (US)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Bassas da India (FR)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Cocos (Keeling) Islands (AU)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Coral Sea Islands (AU)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Jarvis Island (US)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Dhekelia (UK)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Europa Island (FR)<; skipping line; in [1-codes/fips]
[warn] no country match found for >French Polynesia (FR)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Baker Island (US)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Glorioso Islands (FR)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Gaza Strip (PS)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Howland Island (US)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Clipperton Island (FR)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Jan Mayen (NO)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Johnston Atoll (US)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Juan de Nova Island (FR)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Kingman Reef (US)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Kosovo<; skipping line; in [1-codes/fips]
[warn] no country match found for >Palmyra Atoll (US)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Midway Islands (US)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Paracel Islands (CN)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Spratly Islands<; skipping line; in [1-codes/fips]
[warn] no country match found for >South Kuril Islands (RU)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Svalbard (NO)<; skipping line; in [1-codes/fips]
[warn] no country match found for >South Georgia and South Sandwich Islands (UK)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Saint Barthelemy (FR)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Tromelin Island (FR)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Sao Tome and Principe<; skipping line; in [1-codes/fips]
[warn] no country match found for >West Bank<; skipping line; in [1-codes/fips]
[warn] no country match found for >Western Sahara (MA)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Wake Island (US)<; skipping line; in [1-codes/fips]
[warn] no country match found for >Ascension Island<; skipping line; in [1-codes/internet]
[warn] no country match found for >Netherlands Antilles (NL)<; skipping line; in [1-codes/internet]
[warn] no country match found for >Cocos (Keeling) Islands (AU)<; skipping line; in [1-codes/internet]
[warn] no country match found for >French Polynesia<; skipping line; in [1-codes/internet]
[warn] no country match found for >Saint-Pierre and Miquelon<; skipping line; in [1-codes/internet]
[warn] no country match found for >Svalbard and Jan Mayen Islands<; skipping line; in [1-codes/internet]
[warn] no country match found for >Bonaire<; skipping line; in [1-codes/iso]
[warn] no country match found for >Cabo Verde<; skipping line; in [1-codes/iso]
[warn] no country match found for >Cocos (Keeling) Islands (AU)<; skipping line; in [1-codes/iso]
[warn] no country match found for >French Polynesia (FR)<; skipping line; in [1-codes/iso]
[warn] no country match found for >Sao Tome and Principe<; skipping line; in [1-codes/iso]
[warn] no country match found for >Svalbard and Jan Mayen<; skipping line; in [1-codes/iso]
[warn] no country match found for >United States Minor Outlying Islands (US)<; skipping line; in [1-codes/iso]
[warn] no country match found for >Western Sahara<; skipping line; in [1-codes/iso]
[warn] no country match found for >Burma<; skipping line; in [1-codes/motor]
[warn] no country match found for >Zanzibar<; skipping line; in [1-codes/motor]
[warn] no country match found for >Alderney<; skipping line; in [1-codes/motor]
[warn] no country match found for >Transnistria<; skipping line; in [1-codes/motor]
[warn] no country match found for >Kosovo<; skipping line; in [1-codes/motor]
[warn] no country match found for >Western Sahara<; skipping line; in [1-codes/motor]
[warn] city with key barcelona missing
[warn] city with key barcelona missing
[warn] city with key sevilla missing
[warn] city with key valencia missing
[warn] city with key valencia missing
[warn] city with key malaga missing
[warn] city with key bilbao missing
[warn] city with key granada missing
[warn] city with key vigo missing
[warn] city with key sansebastian missing
[warn] city with key valladolid missing
[warn] city with key acoruna missing
[warn] city with key sevilla missing
[warn] city with key elche missing
[warn] city with key almeria missing
[warn] city with key pamplona missing
[warn] city with key villarreal missing
[warn] city with key palma missing
[warn] city with key zaragoza missing
```



# Notes


##  Primera División de España / La Liga

Official Site - [`www.lfp.es` (es)](http://www.lfp.es)

- 20 teams
- 38 rounds (19 x 2) - 10 matches per round
- 380 matches (= 19 x 2 x 10)


### Wikipedia

- [La_Liga](http://en.wikipedia.org/wiki/La_Liga)
- [2013–14_La_Liga](http://en.wikipedia.org/wiki/2013–14_La_Liga)
- [2012–13_La_Liga](http://en.wikipedia.org/wiki/2012–13_La_Liga)

### Wikipedia (es)

- [Primera_División_de_España (es)](http://es.wikipedia.org/wiki/Primera_División_de_España)
- [Primera_División_de_España_2013/14 (es)](http://es.wikipedia.org/wiki/Primera_División_de_España_2013/14)
- [Primera_División_de_España_2012/13 (es)](http://es.wikipedia.org/wiki/Primera_División_de_España_2012/13)


##  Segunda División / Liga Adelante

- 22 teams

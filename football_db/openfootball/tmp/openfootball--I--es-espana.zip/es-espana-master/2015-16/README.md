

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Barcelona                     12   6  0  0  18:5     4  0  2  11:7     29:12  +17   30
 2. Atlético                      12   4  1  1   8:4     4  1  1   9:2     17:6   +11   26
 3. R. Madrid                     12   4  1  1  12:5     3  2  1  13:6     25:11  +14   24
 4. Villarreal CF                 12   4  1  1  11:6     2  2  2   5:6     16:12   +4   21
 5. Celta                         12   2  2  2  12:11    4  1  1  10:8     22:19   +3   21
 6. Eibar                         12   3  2  1   8:5     2  3  1   9:7     17:12   +5   20
 7. Valencia                      12   3  3  0   9:2     2  1  3   8:7     17:9    +8   19
 8. Deportivo                     12   2  3  1  10:6     2  3  1   8:7     18:13   +5   18
 9. Athletic                      12   4  0  2  12:6     1  2  3   6:10    18:16   +2   17
10. Espanyol                      12   3  1  2   6:9     2  0  4   8:14    14:23   -9   16
11. Sevilla                       12   4  0  2  14:10    0  3  3   3:8     17:18   -1   15
12. Betis                         12   1  1  4   5:10    3  2  1   6:7     11:17   -6   15
13. Rayo                          12   3  1  2   8:7     1  1  4   6:13    14:20   -6   14
14. R. Sociedad                   12   1  2  3   6:8     2  1  3   8:6     14:14        12
15. Sporting                      12   1  2  3   5:9     2  1  3   6:9     11:18   -7   12
16. Getafe                        12   3  1  2  10:5     0  1  5   2:14    12:19   -7   11
17. Granada                       12   1  2  3   6:11    1  2  3   7:9     13:20   -7   10
18. Las Palmas                    12   2  2  2   4:3     0  2  4   6:14    10:17   -7   10
19. Levante                       12   1  3  2   6:10    1  1  4   4:13    10:23  -13   10
20. Málaga                        12   2  2  2   5:3     0  1  5   0:8      5:11   -6    9
~~~




---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

